Testirano na Ubuntu.

Uploadajte na pinux mape bin, src te datoteku Makefile (ili ako imate pokrenite na svojem računalu ako imate unix).

Pokretanje je na sljedeći način:

    make startJezKornjacaPuz - simulacija jež/puž/kornjača iz MI 2010/2011
    make startLinuxMicrosoftProgrameri - simulacija programera i njihovog WC-a  
    make startPingPong - jednostavna simulacija ping/pong-a
    make startTrgovacPusaci - simulacija trgovca i 3 pušača
    
Niti jedna simulacija ne ide do beskonačnosti već su ograničene vremenski ili brojem dretvi tako da se slobodno
igrajte brojkama.

Također, implementacija programera je bez izgladnjivanja (što možete vidjeti i iz simulacije).
