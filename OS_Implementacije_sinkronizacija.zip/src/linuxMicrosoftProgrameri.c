#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

#define MAX 10
#define BROJ_PROGRAMERA 30

pthread_mutex_t monitor;

pthread_cond_t linuxRed;
pthread_cond_t windowsRed;

char *nazivi[2] = {"Linux", "Windows"};

pthread_cond_t *redovi[2] = {&linuxRed, &windowsRed};

int cekaona[2] = {0}, unutra = 0, trenutni = -1;


void *programer(void *pparam)
{

    int vrsta = *((int *) pparam);
    
    free(pparam);
    
    pthread_mutex_lock(&monitor);
    
    printf("%s - ulazim\n", nazivi[vrsta]);
    
    if (
        (unutra > 0 && trenutni != vrsta) ||
        (cekaona[!vrsta] > MAX && trenutni == vrsta)
    ) {
        printf("%s - WC zauzet, moram cekat\n", nazivi[vrsta]);
        cekaona[vrsta]++;
        pthread_cond_wait(redovi[vrsta], &monitor);
        cekaona[vrsta]--;
        printf("%s - WC slobodan, ulazim\n", nazivi[vrsta]);
    }
    
    unutra++;
    trenutni = vrsta;
    
    pthread_mutex_unlock(&monitor);
    
    printf("%s - Obavljam nuzdu\n", nazivi[vrsta]);
    
    sleep(rand() % 4 + 1);
    
    
    pthread_mutex_lock(&monitor);
    
    unutra--;
    
    printf("%s - Gotov sam. Izlazim van\n", nazivi[vrsta]);
    
    if (unutra == 0) {
        printf("%s - Zadnji sam, javljam %s\n", nazivi[vrsta], nazivi[!vrsta]);
        pthread_cond_broadcast(redovi[!vrsta]);
    }
    
    pthread_mutex_unlock(&monitor);

    return 0;

}


int main(int argc, char *argv[])
{
    
    pthread_t dretve[BROJ_PROGRAMERA];
    
    int i, *vrsta;
    
    pthread_mutex_init(&monitor, NULL);
    pthread_cond_init(&linuxRed, NULL);
    pthread_cond_init(&windowsRed, NULL);
    
    for (i = 0; i < BROJ_PROGRAMERA; i++) {
        vrsta = malloc(sizeof(int));
        *vrsta = rand() % 2;
        pthread_create(&dretve[i], NULL, programer, vrsta);
    
    }
    
    for (i = 0; i < BROJ_PROGRAMERA; i++) {
        pthread_join(dretve[i], NULL);
    }

    return 0;

}

