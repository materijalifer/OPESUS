#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t jezSem, kornjacaSem, puzSem;

void *jez(void *pparam)
{

    int i = 0;

    while (1) {
    
        i++;
    
        sem_wait(&jezSem);
        
        printf("Jez: %dm\n", i);
        
        sleep(rand() % 2 + 1);
        
        if (i % 2 == 0)
            sem_post(&kornjacaSem);
        else
            sem_post(&jezSem);
    }
    
    return NULL;
    
}

void *kornjaca(void *pparam)
{

    int i = 0;

    while (1) {
    
        i++;
    
       sem_wait(&kornjacaSem);
        
        printf("Kornjaca: %dm\n", i);
        
        sleep(rand() % 2 + 1);
        
        if (i % 2 == 0)
            sem_post(&puzSem);
        else
            sem_post(&jezSem);
            
    }
    
    return NULL;
    
}

void *puz(void *pparam)
{

    int i = 0;

    while (1) {
    
        i++;
    
        sem_wait(&puzSem);
        
        printf("Puz: %dm\n", i);
        
        sleep(rand() % 2 + 1);
        
        sem_post(&jezSem);
    }
    
    return NULL;
    
}

int main(int argc, char *argv[])
{
    
    pthread_t dretve[3];
    
    sem_init(&jezSem, 0, 1);
    sem_init(&kornjacaSem, 0, 0);
    sem_init(&puzSem, 0, 0);
    
    int i;
    
    pthread_create(&dretve[0], NULL, jez, NULL);
    pthread_create(&dretve[1], NULL, kornjaca, NULL);
    pthread_create(&dretve[2], NULL, puz, NULL);
    
    sleep(15);
    
    for (i = 0; i < 3; i++) {
        pthread_cancel(dretve[i]);
    }
    
    sem_destroy(&jezSem);
    sem_destroy(&kornjacaSem);
    sem_destroy(&puzSem);
    
    return 0;
    
}
