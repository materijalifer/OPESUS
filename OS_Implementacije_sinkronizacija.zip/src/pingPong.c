#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t pingSem, pongSem;

void *ping(void *pparam)
{
    
    while (1) {
    
        sem_wait(&pingSem);
        
        printf("Ping\n");
        
        sleep(rand() % 2 + 1);
        
        sem_post(&pongSem);
    }
    
    return NULL;
    
}

void *pong(void *pparam)
{
    
    while (1) {
    
        sem_wait(&pongSem);
        
        printf("Pong\n");
        
        sleep(rand() % 2 + 1);
        
        sem_post(&pingSem);
    }
    
    return NULL;
}

int main(int argc, char *argv[])
{
    
    pthread_t dretve[2];
    
    sem_init(&pingSem, 0, 1);
    sem_init(&pongSem, 0, 0);
    
    int i;
    
    pthread_create(&dretve[0], NULL, pong, NULL);
    pthread_create(&dretve[1], NULL, ping, NULL);
    
    sleep(10);
    
    for (i = 0; i < 2; i++) {
        pthread_cancel(dretve[i]);
    }
    
    sem_destroy(&pingSem);
    sem_destroy(&pongSem);
    
    return 0;
    
}
