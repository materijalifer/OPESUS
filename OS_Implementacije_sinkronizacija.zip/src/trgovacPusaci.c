#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t stolPrazan, stolPun;

int naStolu = 0;

char *sastojci[3] = {"Duhan", "Papir", "Sibice"};
int brojevi[3] = {1, 2, 4};

void *trgovac(void *pparam)
{

    int tmp;

    while (1) {
    
        sem_wait(&stolPrazan);
        
        /* Postavi sastojke na stol */
        tmp = rand() % 3;
        naStolu |= brojevi[tmp];
        naStolu |= brojevi[(tmp + 1) % 3];
        printf("Stavljam sastojke: %s i %s\n", sastojci[tmp], sastojci[(tmp + 1) % 3]);
        
        sem_post(&stolPun); 
         
    }  


    return NULL;
    
}

void *pusac(void *pparam)
{

    int imam = *((int *) pparam);
    
    free(pparam);

    while (1) {
    
        sem_wait(&stolPun);
        
        /* Imam potrebne sastojke? */
        printf("Imam %s, provjeravam sastojke\n", sastojci[imam]);
        if (((naStolu | brojevi[imam]) & 7) == 7) {
        
            /* Uzmi sastojke */
            naStolu = 0;
            printf("Uzimam sastojke\n");
            
            /* Pusi */
            printf("Pusim\n");
            sleep(rand() % 2 + 1);
        
            sem_post(&stolPrazan);
        }
        else {
            printf("Ne trebam te sastojke, pustam drugoga\n");
            sem_post(&stolPun); 
            sleep(rand() % 2 + 1);
        }
    
    }
    
    return NULL;    

}

int main(int argc, char *argv[])
{
    
    pthread_t dretve[4];
    
    sem_init(&stolPrazan, 0, 1);
    sem_init(&stolPun, 0, 0);
    
    int i, *sastojci;
    
    pthread_create(&dretve[0], NULL, trgovac, NULL);
    
    for (i = 1; i < 4; i++) {
        sastojci = malloc(sizeof(int));
        *sastojci = i - 1;
        pthread_create(&dretve[i], NULL, pusac, sastojci);
    }
    
    sleep(10);
    
    for (i = 0; i < 4; i++) {
        pthread_cancel(dretve[i]);
    }
    
    sem_destroy(&stolPrazan);
    sem_destroy(&stolPun);

    return 0;

}

