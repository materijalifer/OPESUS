#include<stdio.h>
#include<signal.h>

#define N 6

static int o_c[N];  //oznaka cekanja;
static int p[N];  //prioritet;
static int t_p;  //tekuci prioritet;
static void p_r( int sig );  //prekidn rutina

static int sig[] = {SIGILL, SIGHUP, SIGSEGV, SIGPIPE, SIGINT};

void z_p(){	//zabrana prekida;	
	int i;
	for(i=0; i<5; i++){
		sighold( sig[i] );
	}
}

void d_p(){	//dozvoli prekidanje;
	int i;
	for(i=0; i<5; i++){
		sigrelse(sig[i]);
	}
}

void o_p( int i ){	//obrada prekida
	sigset( SIGILL, p_r );
        sigset( SIGHUP, p_r);
        sigset(SIGSEGV, p_r);
        sigset(SIGPIPE, p_r);
        sigset(SIGINT, p_r);

	int j = 0;
		switch(i){
		
			case(1): printf("   -  P  -  -  -  -  \n");
			      	for(j=1; j<=5; j++){
					printf("   -  %d  -  -  -  -  \n", j);
					sleep(1);
				}
				printf("   -  K  -  -  -  -  \n");
				break;
	
			case(2): printf("   -  -  P  -  -  -  \n");
			      	for(j=1; j<=5; j++){
					printf("   -  -  %d  -  -  -  \n", j);
					sleep(1);
				}
				printf("   -  -  K  -  -  -  \n");
				break;

			case(3): printf("   -  -  -  P  -  -  \n");
			      	for(j=1; j<=5; j++){
					printf("   -  -  -  %d  -  -  \n", j);
					sleep(1);
				}
				printf("   -  -  -  K  -  -  \n");
				break;


			case(4): printf("   -  -  -  -  P  -  \n");
			      	for(j=1; j<=5; j++){
					printf("   -  -  -  -  %d  -  \n", j);
					sleep(1);
				}
				printf("   -  -  -  -  K  -  \n");
				break;
	

			case(5): printf("   -  -  -  -  -  P  \n");
			      	for(j=1; j<=5; j++){
					printf("   -  -  -  -  -  %d  \n", j);
					sleep(1);
				}
				printf("   -  -  -  -  -  K  \n");
				break;

		}
}

void p_r( int sig ){
	int i, j, n = 1;
	z_p();
	switch(sig){
		
		case(SIGILL): n = 1;
			printf("   -  X  -  -  -  -  \n");
			break;
		
		case(SIGHUP): n = 2;
			printf("   -  -  X  -  -  -  \n");
			break;
		
		case(SIGSEGV): n = 3;
			printf("   -  -  -  X  -  -  \n");
			break;
		
		case(SIGPIPE): n = 4;
			printf("   -  -  -  -  X  -  \n");
			break;
		
		case(SIGINT): n = 5;
			printf("   -  -  -  -  -  X  \n");
			break;
	}
	o_c[n] = 1;
	if(t_p < n){
	do{
		j = 0;
		for(i=t_p+1; i<N; i++){
			if(o_c[i] == 1)
				j = i;
		}

		if(j > 0){
			o_c[j] = 0;
			p[j] = t_p;
			t_p = j;
			d_p;
			o_p(j);
			z_p;
			t_p = p[j];
		}
	}while (j > 0);
	}
	d_p();
}

int main(){
	
	sigset(SIGILL, p_r);
   	sigset(SIGHUP, p_r);
	sigset(SIGSEGV, p_r);
  	sigset(SIGPIPE, p_r);
  	sigset(SIGINT, p_r);

	int i;

	printf("\n Proces obrade prekida, PID = %d ", getpid());
	printf("\n   GP S1 S2 S3 S4 S5 \n \n");
	sleep(10);
	
	for(i=0; i<=9; i++){
		sleep(1);
		printf("   %d  -  -  -  -  -  \n", i);
		}

	for(i=10; i<=20; i++){
		sleep(1);
		printf("  %d  -  -  -  -  -  \n", i);
		}
	
	printf("\n Zavrsio osnovni program ");

	return 0;
}
	
