#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<sys/time.h>
#include<math.h>
#include<stdlib.h>

static int pauza = 0;
static unsigned long broj = 1000000001;
static unsigned long zadnji = 1000000001;


void periodicki_ispis( int sig ){
	printf( "\n zadnji prosti broj: %lu ", zadnji);
}

int postavi_pauzu( int sig ){
	pauza = 1 - pauza;
	return pauza;
}

void prekini(int sig ){
	printf("\n zadnji: %lu ", zadnji);
	exit(0);
}

int prost ( unsigned long n ) {
	unsigned long i, max;

	if ( ( n & 1 ) == 0 ) 
		return 0;

	max = sqrt ( n );
	for ( i = 3; i <= max; i += 2 )
		if ( ( n % i ) == 0 )
			return 0;

	return 1; 
}

int main (){

	struct itimerval t;
	

	
	sigset ( SIGALRM, periodicki_ispis );
	sigset ( SIGTERM, prekini );
	sigset ( SIGINT, postavi_pauzu );
	

	t.it_value.tv_sec = 5;
	t.it_value.tv_usec = 500000;
	
	t.it_interval.tv_sec = 5;
	t.it_interval.tv_usec = 500000;


	
	setitimer ( ITIMER_REAL, &t, NULL );
	
	do{
		if( prost( broj )){
			zadnji = broj;
		}
		broj++;
		while( pauza == 1)
			pause();
	}while(1);
	
	return 0;
}


