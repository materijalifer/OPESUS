#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<sys/time.h>
#include<math.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include <sys/syscall.h>

static int BR_DRETVI = 4;
static int brd[4] = {0, 1, 2, 3};
static int pauza = 0;
unsigned long broj = 1000000001;
unsigned long zadnji = 1000000001;
static int TRAZIM[4], BROJ[4];
pthread_t thr_id[4];

	

void u_KO(int i){ //udi u kriticni odsjecak;
	int j, max;
	TRAZIM[i] = 1;
	max = BROJ[0];
	for(j=0; j<BR_DRETVI; j++){
		if(max<BROJ[j])
			max = BROJ[j];
	}
	BROJ[i] = max + 1;
	TRAZIM[i] = 0;

	for(j=0; j<BR_DRETVI; j++){
		while(TRAZIM[j] != 0);
		while(BROJ[j] != 0 && (BROJ[j] < BROJ[i] || (BROJ[j] == BROJ[i] && j<i)));
	}
}

void i_KO(int i) {  //izadi  iz kriticnog odsjedcka;
	BROJ[i] = 0;
}

void periodicki_ispis( int sig ){
	printf( "zadnji prosti broj: %lu || DRETVA --> id:%u\n", zadnji, (unsigned int)pthread_self());  
}

void postavi_pauzu( int sig ){
	pauza = 1 - pauza;
	int i;
	if(pauza == 0){
		for(i=0; i<BR_DRETVI; i++){
			pthread_kill(thr_id[i], SIGINT);
		}
	}
}

void prekini(int sig ){
	printf("zadnji: %lu\n", zadnji);
	exit(0);
}

int prost ( unsigned long n ) {
	unsigned long i, max;

	if ( ( n & 1 ) == 0 ) 
		return 0;

	max = sqrt ( n );
	for ( i = 3; i <= max; i += 2 )
		if ( ( n % i ) == 0 )
			return 0;

	return 1; 
}




void nista( int sig){
	printf("\n nastavak rada dretve --> id: %u", (unsigned int)pthread_self());
}

void *broji(void *rd){
	int dretva, test, moj;
	dretva = *((int *)rd);
	sigset (SIGINT, nista);	
	do{
		while(pauza == 1)
			pause();
	
		u_KO(dretva);
		moj = broj;
		broj++;
		i_KO(dretva);
		
		test = prost( moj );
		sleep(1);

		u_KO(dretva);
		if( test == 1 && moj>zadnji){
			zadnji = moj;
			printf("iz pomocne %u BR. dretve: %d, %lu\n", (unsigned int)pthread_self(), dretva+1, zadnji);
		}
		i_KO(dretva);
	}while(1);
}

int main (){


	int i;
	struct itimerval t;
	
	sigset ( SIGALRM, periodicki_ispis );
	sigset ( SIGTERM, prekini );
	sigset ( SIGINT, postavi_pauzu );
	
	t.it_value.tv_sec = 1;
	t.it_value.tv_usec = 500000;
	
	t.it_interval.tv_sec = 1;
	t.it_interval.tv_usec = 500000;

	setitimer ( ITIMER_REAL, &t, NULL );

	printf("id:%u",(unsigned int)pthread_self());		
	
	for(i=0; i<BR_DRETVI; i++){ 
		if(pthread_create(&thr_id[i], NULL,(void *)broji,(void *) &brd[i]) != 0){
			printf("Greska pri stvaranju dretve %d\n", i+1);
			exit(0);
		}
		else{
			printf("dretva %d je stvorena\n", i+1);
		}
	}

	
	for(i=0; i<BR_DRETVI; i++){
		pthread_join(thr_id[i], NULL);
	}
		
	return 0;
}


