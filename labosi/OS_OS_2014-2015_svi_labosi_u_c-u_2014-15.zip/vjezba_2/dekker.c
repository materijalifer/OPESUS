#include<stdio.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>


static int PRAVO;
static int ZASTAVICA[2] = {0};

void u_KO(int i, int j){ //udi u kriticni odsjecak;
	ZASTAVICA[j] = 1;
	while( ZASTAVICA[j] != 0 ) {
		if( PRAVO == j) {
			ZASTAVICA[i] = 0;
			while(PRAVO == j);
			ZASTAVICA[i] = 1;
		}
	}
}

void i_KO(int i, int j) {  //izadi  iz kriticnog odsjedcka;
	PRAVO = j;
	ZASTAVICA[i] = 0;
}

void *dretva(void *rbr){
	int k, m;
	for(k=1; k<=5; k++){
		u_KO(*((int *)rbr), 1-*((int *)rbr));
		for(m=1; m<=5; m++){
			printf("Dretva: %d, K.O. br: %d (%d/5)\n", *((int *)rbr)+1, k, m);
			sleep(1);
		}
	       	i_KO(*((int *)rbr), 1-*((int *)rbr));
	}
}

int main(){
	
	int i, br[2];
	pthread_t thr_id[2];
	
	for(i=0; i<2; i++){
		br[i] = i;
		if(pthread_create(&thr_id[i], NULL, (void *) dretva, (void *)&br[i]) != 0){
		printf("Greska pri stvaranju dretve!\n");
		exit(0);
		}
		sleep(3);
	}
	
	for(i=0; i<2; i++){
		pthread_join(thr_id[i], NULL);
	}

return 0;
}
	
