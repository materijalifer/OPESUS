#include<stdio.h>
#include<signal.h>
#include <sys/types.h>
#include<stdlib.h>
#include<time.h>
#include <sys/ipc.h>
#include <sys/shm.h> 
#include <sys/sem.h>
#include <sys/msg.h>
#include <values.h>
#define N 50

int Id;
int *TRAZIM, *BROJ, *STOLOVI;
static int bs;
static int bp;



void brisi(int sig){
	
	(void) shmdt((char *) TRAZIM);
	(void) shmdt((char *) BROJ);
	(void) shmctl(Id, IPC_RMID, NULL);
	exit(0);
}


void u_KO(int i){  //udi u kriticni odsjecak;
	int j, max;
	TRAZIM[i] = 1;
	max = BROJ[0];
	for(j=0; j<bp; j++){
		if(max<BROJ[j])
			max = BROJ[j];
	}
	BROJ[i] = max + 1;
	TRAZIM[i] = 0;

	for(j=0; j<bp; j++){
		while(TRAZIM[j] != 0);
		while(BROJ[j] != 0 && (BROJ[j] < BROJ[i] || (BROJ[j] == BROJ[i] && j<i)));
	}
}

void i_KO(int i){
	BROJ[i] = 0;
}


void rezervacija(int p, int bs){
	
	int ns = 0, bzs = 0, k, bss = 0, Idstola[bs];
		
	while(bzs < bs){
		bss=0;
   		for(k=0; k<bs; k++){
     			if(STOLOVI[k] == 0){
         			Idstola[bss] = k;
          			bss++;
         		}
   		}
	
		
		srand((unsigned)time(NULL));
		sleep(1);
		ns = rand() % bss;
		printf("Proces %d: odabirem stol %d\n", p, Idstola[ns]+1);
		
		if(STOLOVI[Idstola[ns]] == 0){
			u_KO(p);		
			STOLOVI[Idstola[ns]] = p;
			printf("Proces %d: rezerviram stol %d\n", p, Idstola[ns]+1);
			bzs++;		
		}
		else
			printf("Proces %d: neuspjela rezervacija stola %d\n", p, Idstola[ns]+1);
		printf("stanje: \n");
		for(k=0; k<bs; k++){
			if(STOLOVI[k] == 0)
				printf("-");
			else
				printf("%d", STOLOVI[k]);
		}
		printf("\n");
		i_KO(p);
		bss--;
	}
}
			
int main(int argc, char *argv[]){
	
	int i;
	bp = atoi(argv[1]);
	bs = atoi(argv[2]);
	sigset(SIGINT, brisi);

	Id = shmget(IPC_PRIVATE, sizeof(int)*1000, 0600);
	
	if(Id == -1){
		printf("\n GRESKA! Nema zajednicke memorije");
		exit(1);
	}
	
	TRAZIM = (int *)shmat(Id, NULL, 0);
	BROJ = (int *)shmat(Id, NULL, 0) + (N+1)*sizeof(int); 
	STOLOVI = (int *)shmat(Id, NULL, 0) + 2*(N+1)*sizeof(int);
	
	for(i=0; i<bs; i++){
		TRAZIM[i] = 0;
        	BROJ[i] = 0;
		STOLOVI[i] = 0;
	}
	
	for(i=0; i<bp; i++){
		if(fork() == 0){
			rezervacija(i+1, bs);		
			exit(0);
		}
		else if(fork() == -1){
			printf("\n Greška pri stvaranju procesa!");
			exit(1);
		}
	}

	for(i=0; i<bp; i++){
		wait(NULL);
	}
	brisi(0);

return 0;
}
