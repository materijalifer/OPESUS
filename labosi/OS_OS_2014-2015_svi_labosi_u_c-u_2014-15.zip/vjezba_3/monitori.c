#include<stdio.h>
#include<sys/types.h>
#include<sys/sem.h>
#include<pthread.h>
#include<stdlib.h>
#include<string.h>
#include<semaphore.h>
#include<unistd.h>

pthread_mutex_t mutex;
pthread_cond_t red;

char MS[5];
int ulaz = 0, izlaz = 0;
int br_chara = 0;
pthread_t proizvodac_id[100];

void cekaj_slanje(char upis){
	pthread_mutex_lock(&mutex);
	while( br_chara == 5){
		pthread_cond_wait(&red, &mutex);
	}
	br_chara++;
	MS[ulaz] = upis;
	ulaz = (ulaz+1) % 5;
	pthread_mutex_unlock(&mutex);
}
	
void postavi_slanje(){
	pthread_mutex_lock(&mutex);
	pthread_cond_broadcast(&red);
	pthread_mutex_unlock(&mutex);
}

void cekaj_poruku(char *upis, char *back, int *broji_t, int brojac_znakova){
	pthread_mutex_lock(&mutex);
	while(br_chara == 0){
		pthread_cond_wait(&red, &mutex);
	}	
	br_chara--;
	if(MS[izlaz] != '\0'){
		*upis = MS[izlaz];
		*broji_t = *broji_t + 1;
	}else if( *broji_t == brojac_znakova && MS[izlaz] == '\0' ){
		*broji_t = *broji_t + 1;
		*upis = MS[izlaz];
	}
	*back = MS[izlaz];
	izlaz = (izlaz+1) % 5;
	pthread_mutex_unlock(&mutex);
}

void postavi_poruku(){
	pthread_mutex_lock(&mutex);
	pthread_cond_broadcast(&red);
	pthread_mutex_unlock(&mutex);
}

void *proizvodac(char *upis){
	int i = 0;
	int duljina_niza;
	duljina_niza = strlen(upis);
	
	do{
		cekaj_slanje(upis[i]);
		printf("proizvodac %d radi znak: %c\n", (unsigned int)pthread_self(), upis[i]);
		postavi_slanje();
		i++;
		sleep(1);
	}while( i<=duljina_niza );
	sleep(1);
}

void *potrosac( void *brznak ){
	int i = 0, id;
	char s[200];
 	char znak;
	int br_znakova = *((int *) brznak);
	do{
		sleep(1);
		cekaj_poruku(&s[i], &znak, &i, br_znakova);
		printf("potrosac: %c\n", znak);
		postavi_poruku();
	}while( i <= br_znakova );
	printf("znakovi su: %s\n", s);
}

int main( int argc, char *argv[]){
	int i, brpro, brojac_z = 0;
	brpro = argc - 1;

	for(i=0; i<5; i++){
		MS[i] = 0;
	}

	pthread_cond_init(&red, NULL);
	pthread_mutex_init(&mutex, NULL);

	pthread_t potrosac_id;
	
	for(i=0; i<brpro; i++){
		brojac_z = brojac_z + strlen(*(argv+i+1));
		if((pthread_create(&proizvodac_id[i], NULL, (void *)proizvodac, argv[i+1])) !=0 ){
			printf("nemogu stvoriti dretvu\n");
			exit(1);
		}
	}

	if((pthread_create(&potrosac_id, NULL, (void *)potrosac, (void *)&brojac_z)) != 0 ){
		printf("nemogu stvoriti dretvu\n");
		exit(1);
	}
	
	for(i=0; i<brpro; i++)
		pthread_join(proizvodac_id[i], NULL);

	pthread_join(potrosac_id, NULL);
return 0;
}
