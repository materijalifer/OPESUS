#include<stdio.h>
#include<signal.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<time.h>
#include<pthread.h>
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KRED  "\x1B[31m"

int auti = 0;
int smjer_na_mostu;
pthread_mutex_t M;
int broj_auta;
pthread_cond_t red[2];

void popni_se(int smjer){
	pthread_mutex_lock(&M);
	while( auti == 3 || ((auti > 0) && (smjer_na_mostu != smjer)))
		pthread_cond_wait(&red[smjer], &M);
	auti++;
	smjer_na_mostu = smjer;
	pthread_mutex_unlock(&M);		
}

void sidi(int smjer){
	pthread_mutex_lock(&M);
	auti--;
	if(auti == 0){
		pthread_cond_signal(&red[1-smjer]);
		pthread_cond_signal(&red[1-smjer]);
		pthread_cond_signal(&red[1-smjer]);
	}
	else
		pthread_cond_signal(&red[smjer]);
	pthread_mutex_unlock(&M);
}

void prijedi_most(int a){
	printf(KYEL "auto %d prelazi most\n", a+1);
}

void *Auto(void *br_auta){
	int id_auta = *((int *) br_auta);
	srand((unsigned)time(NULL));
	int smjer[100];
	smjer[id_auta] = rand() % 2;
	sleep(1);
	printf(KRED "Auto %d ceka na prelazak preko mosta u smjeru %s\n", id_auta+1, ((smjer[id_auta] == 0) ? "lijevo":"desno"));
	sleep(1);
	popni_se(smjer[id_auta]);
	prijedi_most(id_auta);
	sleep(2);
	sidi(smjer[id_auta]);	
	
	printf(KGRN "Auto %d je presao most u smjeru %s\n", id_auta+1, ((smjer[id_auta] == 0) ? "lijevo":"desno"));
	sleep(1);
}
	

int main(int argc, char *argv[]){
	int i, br[100];
	pthread_t thr_id[100];
	
	broj_auta = atoi(argv[1]);
	srand((unsigned)time(NULL));

	pthread_mutex_init(&M, NULL);
	pthread_cond_init(&red[0], NULL);
	pthread_cond_init(&red[1], NULL);
	
	auti = 0;
	smjer_na_mostu = rand() % 2;

 	for(i=0; i<broj_auta; i++){
		br[i] = i;
		if(pthread_create(&thr_id[i], NULL, (void *) Auto, (void *) &br[i]) != 0){
			printf("Greska pri stvaranju dretve!\n");
			exit(1);
		}
		sleep(1);
	}
	
	for(i=0; i<broj_auta; i++){
		pthread_join(thr_id[i], NULL);
	}

return 0;
}
