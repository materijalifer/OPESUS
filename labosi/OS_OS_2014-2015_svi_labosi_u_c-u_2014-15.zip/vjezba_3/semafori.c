#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/sem.h>
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KRED  "\x1B[31m"

int SemId, Id;
int *ULAZ, *IZLAZ;
typedef struct{
	char spremnik[5];
}buffer;
buffer *meduspremnik;
int pisi = 0;
int pun = 1;
int prazan = 2;
int brpro;


void SemGet(int n){
	SemId = semget(IPC_PRIVATE, n, 0600);
	if (SemId == -1) {
		printf("Nema semafora!\n");
		exit(1);
	}
}

int Semv(int SemNum, int SemVal){  
	return semctl(SemId, SemNum, SETVAL, SemVal);
}

int Semop(int SemNum, int Semop) {  
	struct sembuf SB;
	SB.sem_num = SemNum;
	SB.sem_op  = Semop;
	SB.sem_flg = 0;
	return semop(SemId, &SB, 1);
	}

void Semdestroy(int sig) { 
	(void) semctl(SemId, 0, IPC_RMID, 0);
}

void brisi (int sig){
	(void) shmdt((char *) ULAZ);	
	(void) shmdt((char *) IZLAZ);
	(void) shmdt((char *) meduspremnik);
	(void) shmctl(Id, IPC_RMID, NULL);
	exit(0);
}

void proizvodac (int pro, char *upis) {
	sleep(1);
	int i = 0;
	do {   
		Semop(pun, -1); //cekaj_pun;
		Semop(pisi, -1); //cekaj_pisi;
		meduspremnik->spremnik[*ULAZ] = upis[i];
		printf(KBLU "Proizvodac: %d : znak: %c\n", pro + 1, meduspremnik->spremnik[*ULAZ]);
		*ULAZ = (*ULAZ+1) % 5;
		Semop(pisi, 1); //postavi_pisi;
		Semop(prazan, 1); //postavi_prazan;
		i = i + 1;
		sleep(1);
	 }while(upis[i-1] != '\0');
}

void potrosac(){
	sleep(1);
	char s[100];
	int i = 0;
	int kraj = 0;
	do{
		Semop(prazan, -1);  //cekaj_prazan;
   		if (meduspremnik->spremnik[*IZLAZ] == '\0') {
			kraj++;
			if (kraj == 1) {
				printf(KYEL "potrosac: %c\n",meduspremnik->spremnik[*IZLAZ]);
				*IZLAZ=(*IZLAZ+1)%5;
				Semop(pun, 1); //postavi_pun;
				continue;
			}
  		}
		printf(KYEL "potrosac: %c\n",meduspremnik->spremnik[*IZLAZ]);  
		s[i]=meduspremnik->spremnik[*IZLAZ];
		*IZLAZ=(*IZLAZ+1)%5;
		Semop(pun, 1); //postavi_pun;
		i=i+1;
	}while(kraj != brpro);    
	printf(KGRN "Primljeno je %s\n", s);
}

int main(int argc, char *argv[]){

	int i;
	SemGet(5);
	
	brpro = argc-1;	

	Id=shmget(IPC_PRIVATE,sizeof(int)*100,0600);
	if(Id==-1){
		printf("greska pri stvaranju zajednickog prostora");
		exit (1);
	}

	ULAZ=(int *)shmat(Id,NULL,0);
	*ULAZ=0;

	IZLAZ=(int *)shmat(Id,NULL,0)+1;
	*IZLAZ=0;

	meduspremnik=(buffer *)shmat(Id,NULL,0)+2;
	for(i=0;i<5;i++){
		meduspremnik->spremnik[i]=0;
	}

	Semv(pisi, 1);
	Semv(pun, 5);
	Semv(prazan, 0);

  	sigset(SIGINT, brisi);
	sigset(SIGINT, Semdestroy);

	for (i=0; i<brpro; i++){
		if(fork() == 0){
			proizvodac(i, argv[i+1]);
			exit(0);
 		}
	}

	if(fork() == 0){
		potrosac();
		exit(0);
	}

	for (i=0; i<brpro+1; i++){
		wait(NULL);
	}

return 0;
}
