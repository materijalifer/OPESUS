#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
#include<ctype.h>
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KRED  "\x1B[31m"
#define KCYN  "\x1B[36m"
#define KMAG  "\x1B[35m"
#define KNOR  "\x1B[37m"

struct mem{
	int poc_bloka;
	int vel_bloka;
	int stanje;
	struct mem *sljed;
};
typedef struct mem opisnik;

int memory = 10000;

void ispis(opisnik *glava){
	opisnik *k;
	int i;
	for(k=glava, i = 1; k!=NULL; k=k->sljed, i++){
		printf(KNOR "%d: pocetna adresa = %d, velicina prostora = %d, stanje = %s\n", i, k->poc_bloka, k->vel_bloka, (k->stanje == 1 ? (KRED"zauzeto") : (KGRN"slobodno")));
	}
	return;
}

void trenutno_stanje(int *slobodni, int *zauzeti, opisnik *glava, int *ukupno){
	opisnik *k;
	*zauzeti = 0;
	*slobodni = 0;
	*ukupno = 0;
	for(k=glava; k!=NULL; k=k->sljed){
		if(k->stanje == 0){
			(*slobodni)++;
		}
		else if(k->stanje == 1){
			(*zauzeti)++;
		}
		(*ukupno)++;
	}
	return;
}

void dodijeli(int vel_new, opisnik **glavap){
	opisnik *new, *k;
	int min = memory + 12;
	int adress, imamga, fragmentacija;
	k = *glavap;
	while(k->sljed != NULL){
		if(k->stanje == 0 && k->vel_bloka >= vel_new+12 && k->vel_bloka < min){
			min = k->vel_bloka;
			adress = k->poc_bloka;
		}
		k = k->sljed;		
	}
	
	k = *glavap;
	while(k->sljed != NULL){
		if(k->poc_bloka == adress) 
			break;
		imamga = 1;		
		k = k->sljed;
	}
	
	k->stanje = 1;
	fragmentacija = k->vel_bloka - vel_new - 12;
	if(fragmentacija >= 12){
		k->vel_bloka = vel_new + 12;
		new = (opisnik *) malloc(sizeof(opisnik));
		new->poc_bloka = k->poc_bloka + k->vel_bloka;
		new->vel_bloka = fragmentacija;
		new->stanje = 0;

		if(*glavap == NULL || (*glavap)->poc_bloka >=  new->poc_bloka){

			new->sljed = *glavap;
			*glavap = new;
		}else{
			for(k = *glavap; k->sljed && (k->sljed)->poc_bloka<new->poc_bloka; k = k->sljed);
			new->sljed = k->sljed;
			k->sljed = new;
		}
	}
	return;
}
	

void oslobodi(int start_adress, opisnik **glavap){
	int bingo = 0;	
	opisnik *k, *pom;
	k = *glavap;
	while(k->sljed != NULL){
		if(k->poc_bloka == start_adress && k->sljed->stanje == 0){
			bingo = 1;
			k->stanje = 0;
			k->vel_bloka = k->vel_bloka + k->sljed->vel_bloka;
			pom = k->sljed;
			k->sljed = k->sljed->sljed;
			free(pom);
			k = *glavap;
		}
		else if(k->poc_bloka == start_adress && k->stanje == 1){
			bingo = 1;
			k->stanje = 0;
			k->vel_bloka = k->vel_bloka;
			pom = k->sljed;
			k->sljed = pom;
			k = *glavap;
		}
		else{
			k = k->sljed;
		}
	}
	return;
}


int main(){
	int broj_free;
	int broj_taken;
	int broj_total;
	char choice;
	int  vel_new;
	int start_adress;

	opisnik prvi;
	prvi.poc_bloka = 0;
	prvi.vel_bloka = memory;
	prvi.stanje = 0;
	prvi.sljed = NULL;

	opisnik *glava;
	glava = &prvi;
		
	

	while(1){
		trenutno_stanje(&broj_free, &broj_taken, glava, &broj_total);
		printf(KNOR"RS: #blokova = %d," KGRN"#slobodnih = %d," KRED"#zauzetih = %d\n", broj_total, broj_free, broj_taken);
		ispis(glava);
		printf("\n");

		printf(KRED"DODJELA = D: ");
		printf(KGRN"\nOSLOBODI = O: ");
		printf(KMAG"\nIZLAZ = Q: \n");
		scanf("%s", &choice);
		printf("\n");
	
		switch(choice){
			case 'd':
				printf(KRED"molimo, unesite velicinu memorije koju zelite zauzeti: ");
				scanf("%d", &vel_new);
				dodijeli(vel_new, &glava);
				break;
				
			case 'o':
				printf(KGRN"\nmolimio, unesite adresu memorije koju zelite osloboditi: ");
				scanf("%d", &start_adress);
				oslobodi(start_adress, &glava);
				break;
				
			case 'q':
				printf(KMAG"\nbilo mi je drago,  dođite nam opet\n");
				exit(0);
		}
		printf("\n");
	}
return 0;
}
	
