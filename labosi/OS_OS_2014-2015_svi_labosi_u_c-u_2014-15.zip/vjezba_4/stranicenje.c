#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<time.h>
#include<malloc.h>
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KRED  "\x1B[31m"
#define KCYN  "\x1B[36m"
#define KMAG  "\x1B[35m"


pthread_t *thr_id;
int br_okvira;
int j = 1;
int brojac_za_ispis;
int br_zahtjeva;
typedef struct okvir okej;
struct okvir{
	int stranica;
	int z;
	struct okvir *kaz;
};
int full = 0;
okej *okviri, *klon;
int *zahtjevi = {0};
sem_t del, lru, r_prve, s_prve, idi_dalje;

void rez_okvira(){
	int i;
	
	okviri = (okej *) malloc(br_okvira*sizeof(okej));

	for(i=0; i<br_okvira; i++){
		okviri[i].stranica = 0;
		okviri[i].z = -1;
	}
}

void *delaj(){
	int i, pom;

	zahtjevi = (int *) malloc(sizeof(int)*br_zahtjeva);

	sem_wait(&r_prve);
	for(i=0; i<br_zahtjeva; i++){
		zahtjevi[i] = rand()%10;
	}
	sem_post(&s_prve);
	
	pom = br_zahtjeva;
	sem_wait(&idi_dalje);
	while(br_zahtjeva){
		sleep(1);
		
		sem_wait(&del);

		zahtjevi[pom] = rand()%10;
		pom++;

		br_zahtjeva--;
	
		sem_post(&lru);
	}
}

void ispisi(int shot, int br_stranice, int b_z){
	int i, k;

	if(brojac_za_ispis < 1){
		for(i=j; i<b_z+j; i++){
			printf(KCYN"%d", zahtjevi[i]);
			if(i != b_z-1+j){
				printf(",");
			}else{
				printf(" ");
			}
		}
		j++;
	}

	else if(brojac_za_ispis > 0){
		for(k=0; k<b_z; k++){
			printf(KMAG "%d", zahtjevi[k]);
			if(k != b_z-1){
				printf( ",");
			}else{
				printf( " ");
			}
		}
	}

	brojac_za_ispis--;

	printf("\t%d  ", br_stranice);

	for(i=0; i<br_okvira; i++){
		if(br_stranice == okviri[i].stranica && shot == 0){
			printf(KBLU"(%d) ", okviri[i].stranica);
		}
		else if(okviri[i].stranica == -1){
			printf(" -  ");
		}
		else if(br_stranice == okviri[i].stranica && shot == 1){
			printf(KRED"[%d] ", okviri[i].stranica);
		}
		else{
			printf(KGRN" %d  ", okviri[i].stranica);
		}
	}
	if(shot == 1){
		printf(KRED" KABUM! ");
	}
	printf("\n");
}

int LRU(int *dajmi){
	int i;

	if(!full){
		okviri->stranica = *dajmi;
		okviri->kaz = okviri;
		okviri->z = 1;
		klon = okviri;
		full++;
		return 0;
	}

	else{
		for(i=0; i<full; i++){
			if(klon->stranica == *dajmi){
				klon->z = 1;
				return 1;
			}
			else{
				klon->z = 0;
				klon = klon->kaz;
			}
		}

		if(full < br_okvira){
			okviri[full].stranica = *dajmi;
			okviri[full-1].kaz = okviri + full;
			okviri[full].kaz = okviri;
			klon = okviri + full;
			okviri[full].z = 1;
			full++;
			return 0;
		}
	
		else{
			klon = klon->kaz;
			klon->stranica = *dajmi;
			klon->z = 1;
			return 0;
		}
	}
}


int main(int argc, char *argv[]){
	int i, pom, pom2;

	sem_init(&del, 0, 1);
	sem_init(&lru, 0, 0);
	sem_init(&idi_dalje, 0, 0);
	sem_init(&r_prve, 0, 1);
	sem_init(&s_prve, 0, 0);

	srand((unsigned)time(NULL));

	br_okvira = atoi(argv[1]);
	br_zahtjeva = atoi(argv[2]);

	pom = br_zahtjeva;
	pom2 = br_zahtjeva;
	brojac_za_ispis = br_zahtjeva;

	thr_id = (pthread_t *)malloc(sizeof(pthread_t));	
	
	printf("zahtjevi");
	for(i=0; i<br_zahtjeva; i++){
		printf(" ");
	
	}
	printf("\t#N ");

	for(i=0; i<br_okvira; i++){
		printf(" %d  ", i+1);
	}
	printf("\n");
	for(i=0; i<(8+br_okvira*3+br_zahtjeva*2+3); i++){
		printf("-");
	}
	printf("\n");

	rez_okvira();

	if(pthread_create(thr_id, NULL, delaj, NULL) != 0){
		printf("\n nemogu napraviti dretvu\n");
		exit(1);
	}
	sleep(1);

	int shot, rep;
	
	sem_wait(&s_prve);
	for(i=0; i<br_zahtjeva; i++){
		if(LRU(zahtjevi+i))
			ispisi(1, zahtjevi[i], pom2);
		else
			ispisi(0, zahtjevi[i], pom2);
		sleep(1);	
	}
	sem_post(&idi_dalje);

	while(1){
		
		sem_wait(&lru);
		
		shot = 0;
		rep = LRU(zahtjevi+pom);
		if(rep == 1){
			shot = 1;
		}
		else{
			shot = 0;
		}
		ispisi(shot, zahtjevi[pom], pom2);
		sleep(1);		
		if(br_zahtjeva == 0)
			break;
		pom++;
		sem_post(&del);
	}
	pthread_join(*thr_id, NULL);
	sem_destroy(&del);
	sem_destroy(&lru);
	sem_destroy(&s_prve);
	sem_destroy(&r_prve);
	sem_destroy(&idi_dalje);

return 0;
}
		
	


