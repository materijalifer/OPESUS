#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#define DRETVI 2 
int pravo=0, zastavica[DRETVI]={0};

void ulaz_KO(int i, int j)
{
	zastavica[i]=1;
	while(zastavica[j]!=0){
		if(pravo==j){
			zastavica[i]=0;
			while(pravo==j){
				;
			}
		zastavica[i]=1;
		}
	}
}

void izlaz_KO(int i, int j)
{
	pravo=j;
	zastavica[i]=0;		
}

void *dretva(void *i)
{
	
	int k,m;
	if((int)i==0)
	{
		for(k=1;k<=5;k++)
		{
		ulaz_KO((int)i,1);
			for(m=1;m<=5;m++)
			{
				printf("%i %i %i\n",(int)i,k,m);
				sleep(1);
				fflush(stdout);
			}
		izlaz_KO((int)i,1);			
		}
	}
	else if((int)i==1)
	{
		for(k=1;k<=5;k++)
		{
		ulaz_KO((int)i,0);
			for(m=1;m<=5;m++)
			{
				printf("%i %i %i\n",(int)i,k,m);
				sleep(1);
				fflush(stdout);
			}
		izlaz_KO((int)i,0);			
		}
	}
}
int main(int argc, char *argv[])
{

	int i;
	
	pthread_t threads[DRETVI];
	for(i=0;i<DRETVI;i++)
	{
		pthread_create(&threads[i], NULL, (void* )dretva, (void *)i);
	}

	for(i=0; i<DRETVI; ++i) 
	{
		pthread_join(threads[i], NULL);
	}

}
