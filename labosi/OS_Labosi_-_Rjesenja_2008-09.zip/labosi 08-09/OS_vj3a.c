#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <string.h>
#include <signal.h>

typedef struct{
	int ulaz,izlaz;
	char m[5];
}spremnik;
spremnik *x;

int id,semid;

void proizvodac(int br){
	char string[50];
	int j;
	if(br==1)
		sleep(1);
	SemOp(3,-1);
	printf("Upiši niz za %i. proizvodaca:",br);
	scanf("%s",string);
	SemOp(3,1);
	if (br==0) 
		SemOp(4,-1);
	else 
		SemOp(4,1);
	for(j=0;j<(strlen(string)+1);j++){
		SemOp(1,-1);
		SemOp(0,-1);
		x->m[x->ulaz]=string[j];
		printf("\nproizvodac %i salje \"%c\" potrosacu",br,x->m[x->ulaz]);
		fflush(stdout);
		x->ulaz=(x->ulaz++)%5;
		SemOp(0,1);
		SemOp(2,1);
		sleep(1);
	}

}

void potrosac(){
	sleep(1);
	int i,j=2;
	char niz[100];
	for(i=0;j!=0;i++){
		SemOp(2,-1);
		printf("\npotrosac trosi \"%c\"",x->m[x->izlaz]);
		fflush(stdout);
		niz[i]=x->m[x->izlaz];
		if (x->m[x->izlaz]==0){
			if(j==2)
				i--;
			j--;
		}
		x->izlaz=(x->izlaz++)%5;
		SemOp(1,1);
	}
	printf("\nprimljeno je %s\n",niz);

}

int SemSetVal(int SemNum, int SemVal)
{  /* postavi vrijednost semafora SemNum na SemVal */
   return semctl(semid, SemNum, SETVAL, SemVal);
}

int SemOp(int SemNum, int SemOp)
{  /* obavi operaciju SemOp sa semaforom SemNum */
	struct sembuf SemBuf;
	SemBuf.sem_num = SemNum;
	SemBuf.sem_op  = SemOp;
	SemBuf.sem_flg = 0;
	return semop(semid, &SemBuf, 1);
}
void ciscenje(){
	shmdt(x);
	shmctl(id, IPC_RMID, NULL);
	semctl(semid, 0, IPC_RMID, 0);
}

int main(int argc, char *argv[]){
	/*inicijalizacija zajedničke memorije*/
	id=shmget(IPC_PRIVATE,sizeof(spremnik),0600);
	if(id==-1){printf("\nNema memorije!");exit(1);}
	x=shmat(id,NULL,0);
	
	/*zauzimanje semafora*/
	semid=semget(IPC_PRIVATE,5,0600);
	if(semid==-1){printf("\nNema semafora!");exit(1);}
	/*semafor PIŠI=>0; semafor PUN=>1 semafor PRAZAN=>2 */
	/*semafor proizvodac_upis=>3/*
	
	/*maskiraj signal*/
	sigset(SIGINT,ciscenje);	

	/*inicijaliziraj semafore i varijable u zajedničkoj memoriji*/
	x->ulaz=0;
	x->izlaz=0;
	SemSetVal(0,1);
	SemSetVal(1,5);
	SemSetVal(2,0);
	SemSetVal(3,1); /*radim*/
	SemSetVal(4,0); /*2. gotov*/

	/*pokretanje procesa*/
	int i;
	for(i=0;i<2;i++){
		switch (fork()){		
  		case 0: proizvodac(i);
			exit(0);
		case -1:printf("\nGreška! Proces nemože biti stvoren!");
		}
	
	}
	switch (fork()){		
  		case 0: potrosac();
			exit(0);
		case -1:printf("\nGreška! Proces nemože biti stvoren!");
	}

	
	for(i=0;i<3;i++) 
		wait(NULL); 
	ciscenje();
	return 0;
}

	
