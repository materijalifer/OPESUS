#include <stdio.h>

#include <stdlib.h>

#include <sys/msg.h>



typedef struct {

	long type;

	char ch;

} msgbuf;



int main(int argc, char *argv[]) {

	int msgID, i;

	char *msgKey;



	if (argc != 2) {

		printf("[s] Neispravan broj agumenata\n");

		return 1;

	}

	msgKey = getenv("MSG_KEY");

	if (msgKey == NULL) {

		printf("[s] Okolina ne sadrzi variablu MSG_KEY\n");

		return 1;

	}

	printf("[s] Okolina sadrzi variablu MSG_KEY=%s\n", msgKey);

	msgID = msgget(atoi(msgKey), 0600);

	if (msgID == -1) {

		printf("[s] Ne postoji red poruka\n");

		return 1;

	}



	i = 0;

	do {

		msgbuf buffer;

		buffer.type = 1;

		buffer.ch = argv[1][i];

		if (msgsnd(msgID, &buffer, 1, 0) == -1) {

			printf("[s] Greska pri slanju poruke\n");

			return 1;

		}

	} while (argv[1][i++] != '\0');



	printf("[s] Zavrsio\n");

	return 0;

}
