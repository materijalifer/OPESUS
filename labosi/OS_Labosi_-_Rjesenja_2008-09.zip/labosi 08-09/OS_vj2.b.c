#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h> 

extern int random_prime();

int main(int argc, char *argv[])
{
	int i,j,ptime,proceses;
	proceses=atoi(argv[2]);	
	ptime=atoi(argv[1]);
	
	for(i=0;i<proceses;i++)	{
		switch (fork()) {
  		case 0: 
			for(j=0;j<ptime;j++){
				fflush(stdout);				
				printf("\nproces pid=%i broj=%i",getpid(),random_prime());
				fflush(stdout);
				sleep(1);
				fflush(stdout);
			}
			if(j==ptime){
				printf("\nproces pid=%i je završio!",getpid());
				fflush(stdout);
				exit(0);
			}
		case -1:printf("\nGreška! Proces nemože biti stvoren!");
		
   		//default:nastavak posla roditelja;

   		}
	}

 

while (i--) wait (NULL);

return 0;
}
