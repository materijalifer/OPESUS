#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<string.h>
#include<limits.h>

int najmanji(unsigned long int* polje,int duljina){
	unsigned long int najmanji=ULONG_MAX;
	int indx_naj=-1;
	int i;
	for(i=0;i<duljina;i++){
		if(*(polje+i)<najmanji)
			najmanji=*(polje+i);
			indx_naj=i;
	}
	return indx_naj;
}

int main(int argc, char *argv[]){

	if(argc<3){
		printf("nedovoljno argumenata!");
		exit(2);
	}
	
	char *zahtjevi,*stranice;
	unsigned long int *rabljeno;
	int br_str,br_rq;
	int i;
	int pogodak=0;
	int temp; /*makni temp*/

	br_str=atoi(argv[1]);
	br_rq=atoi(argv[2]);

	stranice=(char*)calloc(br_str+1,sizeof(int));
	zahtjevi=(char*)malloc(br_rq*sizeof(int));
	rabljeno=(int*)calloc(br_str,sizeof(int));

	sleep(1);
	printf("%li",clock());
	
	

	memset(stranice,'-',br_str);

	srand((unsigned)time(NULL));	

	for(i=0;i<br_rq;i++){ /*izmisli zahtjeve stranica*/
		*(zahtjevi+i)=48+rand()%(8-1)+1;
	}
	
	printf("Zahtjevi: "); /*ispis zahtjeva*/
	for(i=0;i<br_rq;i++){
		printf("%c",zahtjevi[i]);
		if(i!=br_rq-1)
			printf(",");
	}

	printf("\n#N",2); /*ispiši redni broj stranice*/
	for(i=0;i<br_str;i++){
		printf("%*i",3,i+1);	
	}

	printf("\n");/*podvuci crtu*/
	for(i=0;i<br_str*4;i++)
		printf("-");
	printf("\n");

	
	for(i=0;i<br_rq;i++){
		if(strchr(stranice,zahtjevi[i])!=NULL){ //da li je pogodak
			pogodak=1;
			*(rabljeno+i)=i;
			printf("!!!%c\n",zahtjevi[i]);
			continue;
		}
		else if(strchr(stranice,'-')!=NULL){ /*ako nije pogodak pogle jel ima slobodnog mjesta*/
			*(strchr(stranice,'-'))=*(zahtjevi+i);
			*(rabljeno+i)=i;
		}
		else if(strchr(stranice,'-')==NULL){/*ako nema izbaci nekog*/
			temp=najdulji(rabljeno,br_str);
			printf("???%c\n",stranice[temp]);
			
		}
		printf("%i %i %i %i %i\n",rabljeno[0],rabljeno[1],rabljeno[2],rabljeno[3],rabljeno[4]);
		puts(stranice);
	}
	
	
return 0;
}

