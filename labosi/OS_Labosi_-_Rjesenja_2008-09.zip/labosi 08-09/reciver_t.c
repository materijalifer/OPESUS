#include <errno.h>

#include <signal.h>

#include <stdio.h>

#include <stdlib.h>

#include <sys/msg.h>

#include <unistd.h>



typedef struct {

	long type;

	char ch;

} msgbuf;



int msgID;



void cleanup(int signal) {

	msgctl(msgID, IPC_RMID, NULL);

	exit(0);

}



int main(void) {

	int i, noWait;

	char *msgKey, message[256];



	msgKey = getenv("MSG_KEY");

	if (msgKey == NULL) {

		printf("[R] Okolina ne sadrzi variablu MSG_KEY\n");

		return 1;

	}
	sleep(1);
	printf("[R] Okolina sadrzi variablu MSG_KEY=%s\n", msgKey);

	msgID = msgget(atoi(msgKey), 0600);

	if (msgID == -1) {

		printf("[R] Ne postoji red poruka\n");

		return 1;

	}

	sigset(SIGINT, cleanup);



	i = 0;

	noWait = 0;

	while (1) {

		msgbuf buffer;

		if (msgrcv(msgID, &buffer, 1, 0, noWait ? IPC_NOWAIT : 0) == -1) {

			if (noWait && errno == ENOMSG)

				break;

			else {

				printf("[R] Greska pri primanju poruke\n");

				cleanup(0);

			}

		}

		message[i++] = buffer.ch;

		printf("[R] Received: %c\n", buffer.ch);

		if (buffer.ch == '\0') {

			printf("[RECEIVED]: %s\n", message);

			i = 0;

			noWait = 1;

			printf("[R] Idle...\n");

			sleep(1);

		} else

			noWait = 0;

	}



	printf("[R] Zavrsio\n");

	cleanup(0);

	return 0;

}
