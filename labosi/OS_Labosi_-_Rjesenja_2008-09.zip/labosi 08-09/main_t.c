#include <stdio.h>

#include <stdlib.h>

#include <sys/msg.h>

#include <sys/types.h>

#include <unistd.h>



int main(int argc, char *argv[]) {

	int msgID, uid, i;

	char env[32];

	struct msqid_ds state;



	if (argc < 2) {

		printf("Neispravan broj argumeneta\n");

		return 1;

	}

	uid = getuid();

	msgID = msgget(uid, IPC_CREAT | 0600);

	if (msgID == -1) {

		printf("Greska pri stvaranju reda poruka\n");

		return 1;

	}

	state.msg_perm.uid = uid;

	state.msg_perm.gid = getgid();

	state.msg_perm.mode = 0600;

	state.msg_qbytes = 5;

	msgctl(msgID, IPC_SET, &state);



	sprintf(env, "MSG_KEY=%d", uid);

	putenv(env);

	for (i = 1; i < argc; ++i) {

		switch (fork()) {

		case -1:

			printf("Greska pri stvaranju novog procesa\n");

			return 1;

		case 0:

			execl("./sender_t", "sender", argv[i], NULL);

			printf("Greska pri stvaranju novog procesa\n");

			return 1;

		}

	}

	execl("./reciver_t", "reciver", NULL);

	printf("123Greska pri stvaranju novog procesa\n");

	return 1;

}
