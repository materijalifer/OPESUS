#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void prekid(int sig)
{
	if(sig==SIGQUIT)
		{
		sighold(SIGTSTP);
		int i;
		for(i=0;i<6;i+=1)
			{
			printf("Q");
			fflush(stdout);
			usleep(100000);	
  			}
		sigrelse(SIGTSTP);
		}
	else if(sig=SIGTSTP)
		{
		sighold(SIGQUIT);
		int j;
		for(j=0;j<6;j+=1)
			{
			printf("Z");
			fflush(stdout);
			usleep(100000);	
			}
		sigrelse(SIGQUIT);
		}
}

int main()
{
	int i;
	for(i=0;;i++)
		{
		printf("X");
		fflush(stdout);
		sleep(1);
		if(i==10)
			{
			sigset(SIGQUIT,prekid);
			sigset(SIGTSTP,prekid);
			printf("\n\t****Signal SIGQUIT inicijaliziran****\n\t****Signal SIGTSTP inicijaliziran****\n");
			}
		}



	printf("\nProgram završio!\n");
	return 0;
}
