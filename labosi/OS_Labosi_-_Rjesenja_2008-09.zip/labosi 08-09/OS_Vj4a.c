#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
 

struct msgbuf{
	long mtype;
	char data[];
	}msg;

int main(int argc, char *argv[]){
	int *key;
	int msgid;
	int i,temp;	
	if(argc!=2){
		perror("\n[s]Neispravan broj ulaznih argumenata!");
		exit(-1);
	}

	key=getenv("MSG_KEY");
	if(key==NULL){
		perror("\n[s]MSG_KEY greska");
		exit(-1);
	}
	printf("\n[s]MSG_KEY=%i",key);
	msgid=msgget(key,0600);
	if(msgid==-1){
		perror("\n[s]ne postoji red poruka!");
		exit(-1);
	}
	for(i=0;i<strlen(argv[1])+1;i++){
		msg.mtype=1;
		msg.data=argv[1][i];
		temp=msgsnd(msgid,*msg,1,0);
		if(temp==-1){
			perror("\n[s]Greška pri slanju poruke!");
			exit(-1);
		}
	printf("Sender zavrsio!");
	}
}
