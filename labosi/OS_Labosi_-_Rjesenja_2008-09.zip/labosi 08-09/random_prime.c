#include <time.h>
#include <math.h>
#include <unistd.h>
#include <stdlib.h>
          
int random_prime()
{
	static unsigned int seed = -1;
	unsigned int i, a, x, max_q;
	
	if (seed == -1)
		seed = time(NULL) + getpid();

	while ((x = rand_r(&seed)) < 10)
		;

	x |= 1; /* make him odd if its not */

	max_q = (int) sqrt((double) x);

	for (i = x; ; i += 2) {
		for (a = 3; a <= max_q; a += 2)
			if ((i % a) == 0)
				break;
		if (a > max_q)
			break; /* 'i' is prime */
	}

	return i;
}

/* Koristenje funkcije iz druge datoteke, npr. vj2.c:
 *
 * U vj2.c negdje ispod 'include'-ova dodat:
 *   extern int random_prime();
 *
 * Prevodjenje:
 *  gcc vj2.c random_prime.c -lm
 *
 * Pokretanje:
 *  ./a.out 5 10
 */
