#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <unistd.h>


int main(int argc, char *argv[]){
	char value[20];
	int msgid;
	int uid;
	struct msqid_ds buf;
	int i;

	if(argc<2){
		printf("Nema dovoljno argumenata!");
		exit(-1);
	}
	uid = getuid();
	sprintf(value, "MSG_KEY=%d", uid);
	putenv(value);
	msgid=msgget(uid,0600 | IPC_CREAT);
	if(msgid==-1){
		printf("Nije moguce stvoriti red poruka!");
		exit(-1);
	}
	buf.msg_perm.uid = getuid();
	buf.msg_perm.gid = getgid();
	buf.msg_perm.mode = 0600;
	buf.msg_qbytes = 5;
	msgctl(msgid,IPC_SET,&buf);
	for(i=1;i<argc;++i){
		switch (fork()) {
  			case 0: execl("./sender", "sender", argv[i], NULL);
				printf("Greska pri stvaranju novog procesa\n");
				return 1;
			case 1:	printf("Greska pri stvaranju novog procesa\n");
				return 1;
		}
	}
	switch (fork()) {
  			case 0: execl("./reciver", "reciver", NULL);
				printf("Greska pri stvaranju novog procesa\n");
				return 1;
			case 1:	printf("Greska pri stvaranju novog procesa\n");
				return 1;
		}
	while (i--) wait (NULL);	
	return 1;
}
