#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

char filozof[6]={'O','O','O','O','O',0};
int vilica[5]={1,1,1,1,1};
pthread_cond_t red[5];
pthread_mutex_t monitor;

void jesti(int n){
   	pthread_mutex_lock(&monitor);
	filozof[n] = 'o';
	while(vilica[n] == 0 || vilica[(n + 1) % 5] == 0)
    		pthread_cond_wait(&red[n],&monitor);
	vilica[n] = vilica[(n + 1) % 5] = 0;
	filozof[n] = 'X';
	printf("\n%s (%i)",filozof, n+1);
	fflush(stdout);
	pthread_mutex_unlock(&monitor);
	/*njam_njam;*/ sleep(2);

	pthread_mutex_lock(&monitor); 
	filozof[n] = 'O';
	vilica[n] = vilica[(n + 1) % 5] = 1;
	if(n==0){
		pthread_cond_signal(&red[4]);
	}else{
		pthread_cond_signal(&red[n-1]);
	}
	printf("\n%s (%i)",filozof, n+1);
	fflush(stdout);
   	pthread_mutex_unlock(&monitor); 
}
	
void misliti(){
	/*misli*/ sleep(3);
}

void *filozofi(void *i){
	while(1){
	misliti();
	jesti((int)i);
	}
}

int main(int argc, char *argv[]){
	pthread_t threads[5];
	int i;
	pthread_mutex_init(&monitor, NULL);
	pthread_cond_init(red, NULL);

	for(i=0;i<5;i++){
		pthread_create(&threads[i], NULL, (void* )filozofi, (void *)i);
	}
	for(i=0; i<5; ++i){
		pthread_join(threads[i], NULL);
	}
	return 0;
}

