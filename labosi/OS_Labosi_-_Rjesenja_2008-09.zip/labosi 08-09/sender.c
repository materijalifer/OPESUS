#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
 

struct msgbuf{
	long mtype;
	char data[1];
	}msg;

int main(int argc, char *argv[]){
	char *key;
	int msgid;
	int i,temp;	
	char poruka[100];
	if(argc!=2){
		printf("[s]Neispravan broj ulaznih argumenata!\n");
		exit(-1);
	}
	
	strcpy(poruka,argv[1]);

	key=getenv("MSG_KEY");
	if(key==NULL){
		printf("[s]MSG_KEY greska\n");
		exit(-1);
	}
	printf("\n[s]MSG_KEY=%s",key);
	fflush(stdout);
	msgid=msgget(atoi(key),0600);
	if(msgid==-1){
		printf("\n[s]ne postoji red poruka!\n");
		exit(-1);
	}
	for(i=0;i<strlen(argv[1])+1;i++){
		msg.mtype=1;
		msg.data[0]=poruka[i];
		temp=msgsnd(msgid,&msg,1,0);
		if(temp==-1){
			printf("\n[s]Greška pri slanju poruke!\n");
			exit(-1);
		}
	
	}
	printf("\nSender zavrsio!");
	
return 0;
}
