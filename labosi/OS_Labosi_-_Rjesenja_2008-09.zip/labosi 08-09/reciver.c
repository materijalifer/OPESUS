#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

struct msgbuf{
	long mtype;
	char data[1];
	}msg;

int msgid;

void spavanje(){
int j;
printf("\n[r]");
			for(j=0;j<25000000;j+=5000000){
				printf("Z");
				fflush(stdout);
				usleep(500000);
				printf("z");
				fflush(stdout);
			}
}

void brisi_red_poruka(){
	msgctl(msgid,IPC_RMID,NULL);
	exit(0);
}

int main(int argc, char *argv[]){
	char *key;
	int i,z=0,temp,pokusaji=0;
	char poruka[100];
	usleep(100);
	key=getenv("MSG_KEY");
	if(key==NULL){
		printf("[s]MSG_KEY greska\n");
		exit(-1);
	}
	msgid=msgget(atoi(key),0600);
	if(msgid==-1){
		printf("\n[s]ne postoji red poruka!\n");
		exit(-1);
	}
	sigset(SIGINT,brisi_red_poruka);
	for(i=0;;){
		temp=msgrcv(msgid,&msg,1,0,z); /*z=zastavica da li da čeka ili ne*/
		if(temp==-1){
				pokusaji++;
				spavanje();
				if(pokusaji>9)
					goto kraj;	
			
		}
		else {
			poruka[i++]=msg.data[0];
			printf("\n[r]reciver primio:%c",msg.data[0]);
			fflush(stdout);
			if(msg.data[0]=='\0'){
				printf("\n[r]Primljeno:%s",poruka);
				strcpy(poruka,"");
				i=0;
				z=IPC_NOWAIT;
				pokusaji=0;
			}
			else
				z=0;
		}
		
	}
kraj:	printf("\n[r]Reciver zavrsio, nema više poruka!\n");
	fflush(stdout);
	brisi_red_poruka();
	return 0;
}
