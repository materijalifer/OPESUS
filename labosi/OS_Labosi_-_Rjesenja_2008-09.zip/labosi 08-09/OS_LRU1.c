#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<string.h>
#include<limits.h>

int najmanji(int* polje,int duljina){
	int najmanji=INT_MAX;
	int indx_naj=-1;
	int i;
	for(i=0;i<duljina;i++){
		if(*(polje+i)<najmanji){
			najmanji=*(polje+i);
			indx_naj=i;
		}
	}
	return indx_naj;
}

int main(int argc, char *argv[]){

	if(argc<3){
		printf("nedovoljno argumenata!");
		exit(2);
	}
	char *zahtjevi,*stranice;
	int *rabljeno;
	int br_str,br_rq;
	int i,j;
	int pogodak=0,br_pogodaka=0;
	int temp; /*makni temp*/
	char *temp2;

	br_str=atoi(argv[1]);
	br_rq=atoi(argv[2]);

	stranice=(char*)calloc(br_str+1,sizeof(int));
	zahtjevi=(char*)malloc(br_rq*sizeof(int));
	rabljeno=(int*)calloc(br_str,sizeof(int));

	memset(stranice,'-',br_str);

	srand((unsigned)time(NULL));	

	for(i=0;i<br_rq;i++){ /*izmisli zahtjeve stranica*/
		*(zahtjevi+i)=48+rand()%(8-1)+1;
	}

	printf("Zahtjevi: "); /*ispis zahtjeva*/
	for(i=0;i<br_rq;i++){
		printf("%c",zahtjevi[i]);
		if(i!=br_rq-1)
			printf(",");
	}

	printf("\n#N",2); /*ispiši redni broj stranice*/
	for(i=0;i<br_str;i++){
		printf("%*i",3,i+1);	
	}

	printf("\n");/*podvuci crtu*/
	for(i=0;i<br_str*4;i++)
		printf("-");
	printf("\n");

	for(i=0;i<br_rq;i++){
		if(strchr(stranice,zahtjevi[i])!=NULL){ //da li je pogodak
			pogodak=1;
			temp2=strchr(stranice,zahtjevi[i]); /*na kojoj poziciji u polju stranice se nalazi pogodak*/
			rabljeno[temp2-stranice]=i;
		}
		else if(strchr(stranice,'-')!=NULL){ /*ako nije pogodak pogle jel ima slobodnog mjesta*/
			temp2=strchr(stranice,'-');
			rabljeno[temp2-stranice]=i;
			*(strchr(stranice,'-'))=*(zahtjevi+i);
		}
		else if(strchr(stranice,'-')==NULL){/*ako nema slobodnog mjesta izbaci nekog*/
			temp=najmanji(rabljeno,br_str);
			*(stranice+temp)=*(zahtjevi+i);
			rabljeno[temp]=i;		
		}
		printf("%c%*c",zahtjevi[i],1,' ');/*ispis trenutnog zahtjeva*/
		for(j=0;j<br_str;j++){	/*ispis trenutnog sadrzaja u stranici*/
			printf("%*c",3,stranice[j]);
		}
		if(pogodak!=0){
			printf(" !!!pogodak");
			pogodak=0;
			br_pogodaka++;
		}
		printf("\n");		
	}
	printf("Broj pogođenih:  %i\nBroj promašanih: %i\n",br_pogodaka,br_rq-br_pogodaka);	
	return 0;
}

