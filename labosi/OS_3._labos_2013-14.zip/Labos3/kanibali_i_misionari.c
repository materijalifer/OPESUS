#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<time.h>
#define desno 1
#define lijevo 0
#define misionar 1
#define kanibal 0

pthread_mutex_t M;
pthread_cond_t red[7];

int br[2][2];
int brmisionara=0;
int brkanibala=0;
int br_putnika;
int camac_obala, not_camac;
int ukrcavanje=0;
int iskrcavanje=0;
int lkanibal=0;
int dkanibal=0;
int lmisionar=0;
int dmisionar=0;
int camac=2;

void *Kanibal(){
	int obala;
	obala=rand()%2;
	not_camac=rand()%2;
	pthread_mutex_lock(&M);
	brkanibala++;
	br[obala][0]++;
	if(not_camac==1){ 
		not_camac=rand()%2;
	}
	while(not_camac==1){
		if((obala==camac_obala)&&(br_putnika<7)&&(brkanibala<brmisionara)){
			printf("Ulazim u camac!\n");
			br[obala][0]--;		
			br_putnika++;
		}
		if(br_putnika==3){
			pthread_cond_signal(&red[ukrcavanje]);
		}
		if((br_putnika>=3)&&(br_putnika<7)&&(br[obala][1]>0)){
			if(obala==1){
				pthread_cond_signal(&red[dmisionar]);
			}else{
				pthread_cond_signal(&red[lmisionar]);
			}
		}else{
			if(obala==1){
				pthread_cond_wait(&red[dkanibal], &M);
			}else{
				pthread_cond_wait(&red[lkanibal], &M);
			}
		not_camac=rand()%2;
		}
	pthread_cond_wait(&red[camac], &M);
	printf("Iskrcavam se!\n");
	br_putnika--;
	if(br_putnika==0){
		pthread_cond_signal(&red[iskrcavanje]);
	}
pthread_mutex_unlock(&M);
}
}
void *Misionar(){
	int obala;
	obala=rand()%2;
	not_camac=rand()%2;
	pthread_mutex_lock(&M);
	brmisionara++;
	br[obala][1]++;
	camac_obala=rand()%2;
	
	if(not_camac==1){
		not_camac=rand()%2;
	}
	while(not_camac==1){
		if((obala==camac_obala)&&(br_putnika<7)&&(brkanibala<brmisionara)){
			printf("Ulazim u camac!\n");
			br[obala][1]--;		
			br_putnika++;
		}
		if(br_putnika==3){
			pthread_cond_signal(&red[ukrcavanje]);
		}
		if((br_putnika>=3)&&(br_putnika<7)&&(br[obala][0]>0)){
			if(obala==1){
				pthread_cond_signal(&red[dkanibal]);
			}else{
				pthread_cond_signal(&red[lkanibal]);
			}
		}else{
			if(obala==1){
				pthread_cond_wait(&red[dmisionar], &M);
			}else{
				pthread_cond_wait(&red[lmisionar], &M);
			}
		not_camac=rand()%2;
		}
	pthread_cond_wait(&red[camac], &M);
	printf("Iskrcavam se!\n");
	br_putnika--;
	if(br_putnika==0){
		pthread_cond_signal(&red[iskrcavanje]);
	}
pthread_mutex_unlock(&M);
}
}
void *Shuma(){
	int n;
	pthread_t desnikanibal;
	pthread_t lijevikanibal;
	pthread_t desnimisionar;
	pthread_t lijevimisionar;
	srand((unsigned)time(NULL));
	while(1){
		n=rand()%2;
		if(n==1){
			if(pthread_create(&desnikanibal, NULL, Kanibal, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}else{
			if(pthread_create(&lijevikanibal, NULL, Kanibal, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}
		}
		sleep(1);
		n=rand()%2;
		if(n==1){
			if(pthread_create(&desnimisionar, NULL, Misionar, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}else{
			if(pthread_create(&lijevimisionar, NULL, Misionar, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}
		}
		n=rand()%2;
		if(n==1){
			if(pthread_create(&desnikanibal, NULL, Kanibal, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}else{
			if(pthread_create(&lijevikanibal, NULL, Kanibal, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}
		}
		sleep(1);
	 }
}
}}
}

void *Camac(){
	int i, obala;
	obala=rand()%2;
	while(1){
		pthread_cond_wait(&red[ukrcavanje], &M);
		sleep(1);
		if(obala==1){
			obala=0;
		}else{
			obala=1;
		}
		printf("Prevozim preko rijeke...\n");
		sleep(1);
		for(i=1; i<br_putnika; i++){
			pthread_cond_signal(&red[camac]);
		}
		pthread_cond_wait(&red[iskrcavanje], &M);
		if(obala==1){
			for(i=1; i<br[obala][1]; i++){
				pthread_cond_signal(&red[dmisionar]);
			}
			for(i=1; i<br[obala][0]; i++){
				pthread_cond_signal(&red[dkanibal]);
			}
		}else{
			for(i=1; i<br[obala][1]; i++){
				pthread_cond_signal(&red[lmisionar]);
			}
			for(i=1; i<br[obala][0]; i++){
				pthread_cond_signal(&red[lkanibal]);
			}
		}
	}
}

int main(int argc, char *argv[]){
	pthread_mutex_init(&M, NULL);
	pthread_mutex_init(&red, NULL);
	
	pthread_t canibal;
	pthread_t missionar;
	pthread_t camac;
	pthread_t shuma;
	
	if(pthread_create(&shuma, NULL, Shuma, NULL)){
		printf("Ne mogu stvoriti dretvu!\n");
		exit(1);
	}	
	
	if(pthread_create(&canibal, NULL, Kanibal, NULL)){
		printf("Ne mogu stvoriti dretvu!\n");
		exit(1);
	}
	if(pthread_create(&missionar, NULL, Misionar, NULL)){
		printf("Ne mogu stvoriti dretvu!\n");
		exit(1);
	}
	if(pthread_create(&camac, NULL, Camac, NULL)){
		printf("Ne mogu stvoriti dretvu!\n");
		exit(1);
	}
	pthread_join(shuma, NULL);
	pthread_join(canibal, NULL);
	pthread_join(missionar, NULL);
	pthread_join(camac, NULL);
return(0);
}







	


	


		







