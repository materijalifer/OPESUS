#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>

pthread_cond_t red[3];
pthread_mutex_t M;
//deklaracije varijabli
int br_sobova=0;
int br_patuljaka=0;
int br_djece=0;
int br_poklona=0;
int djedmraz=0;
int sobovi=1;
int konzultacije=2;
int djeca=1;

void *Patuljak(){
	printf("Patuljak kuca!\n");
	pthread_mutex_lock(&M);
	br_patuljaka++;
	br_poklona++;
	if(br_patuljaka == 3){
		pthread_cond_signal(&red[djedmraz]);
	}
	pthread_cond_wait(&red[konzultacije],&M);
	pthread_mutex_unlock(&M);
}

void *Sob(){
	printf("Sob zove!\n");
	pthread_mutex_unlock(&M);
	br_sobova++;
	if(br_sobova == 9){
		pthread_cond_signal(&red[djedmraz]);
	}
	pthread_cond_wait(&red[sobovi],&M);
	pthread_mutex_unlock(&M);
}

void *Dijete(){
	printf("Dijete ceka!\n");
	pthread_mutex_lock(&M);
	br_djece++;
	if(br_djece == 2){
		pthread_cond_signal(&red[djedmraz]);
	}
	pthread_cond_wait(&red[djeca],&M);
	pthread_mutex_unlock(&M);
}

void *Sjeverni_Pol(){
	srand((unsigned)time(NULL));
	pthread_t sob;
	pthread_t patuljak;
	pthread_t dijete;

       	int probs_sobovi, probs_patuljci, cekanje;
	while(1){
		cekanje=rand()%3+1;
		sleep(cekanje);
		probs_sobovi=rand()%101;
		probs_patuljci=rand()%101;
		if((probs_sobovi>50)&&(br_sobova<10)){
			if(pthread_create(&sob,NULL,Sob, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}
		}
		if(probs_patuljci>50){
			if(pthread_create(&patuljak,NULL,Patuljak, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}
		}
		if(br_poklona==1){
			if(pthread_create(&dijete, NULL, Dijete, NULL)){
				printf("Ne mogu stvoriti dretvu!\n");
				exit(1);
			}
		}
	}
}

void *Djed_Mraz(){
	int n;
	pthread_mutex_lock(&M);
	while(1){
		pthread_cond_wait(&red[djedmraz],&M);
		if((br_sobova == 10)&&(br_patuljaka>0)){
			printf("Ukrcavam poklone i raznosim!\n");
			sleep(2);
			pthread_cond_broadcast(&red[sobovi]);
	printf("Sobovi su spremni, pokloni spremni, Djedo poklone dijeli!\n");
                                                       
printf("    *                                                         *         \n");
printf("                          *                         *      _.--.        \n");
printf("     \\ / \\ / \\ /                                        /   /=*      \n");
printf("       \\ /  \\ /                   *                ... (_____)        \n");
printf("        \\^ ^/                                      \\ \\_((^o^))-.    * \n");
printf("        (O)(O)--)--------\\.                         \\   (   ) \\  \\._.\n");
printf("        |    |  ||============((~~~~~~~~~~~~~~))|        ( )   |    \\ \n");
printf("         \\__/             ,,   \\. * * * * * *./    (~~~~~~~~~~~)   \\ \n");
printf("  *      ||^||\\.____./|| |       \\__________/         ~||~~~~|~'\\____/\n");
printf("         || ||     || || A         ||    ||            ||    |    \n");
printf("    *    <> <>     <> <>       (___||____||____)      ((~~~~~|   *\n");
			br_sobova=0;
		}
		if(br_sobova==9){
			printf("Djed hrani sobove...\n");
		}
		if(br_poklona == 9){
			printf("Djed pita djecu sto zele za Bozic i daje poklone!\n");
		}			
		while(br_patuljaka>=3){
			printf("Rasprava s patuljcima...\n");
			sleep(2);
			for(n=3; n>0; n--){
				pthread_cond_signal(&red[konzultacije]);
			}
			br_patuljaka-=3;
		}
	}
	pthread_mutex_unlock(&M);
}


int main(int argc, char *argv[]){

	pthread_mutex_init(&M, NULL);
	pthread_cond_init(red,NULL);
	pthread_t djedo;
	pthread_t pol;
	int f;

	f=pthread_create(&djedo, NULL, Djed_Mraz, NULL);
	if(f){
		printf("Ne mogu stvoriti dretvu!\n");
		exit(1);
	}
	f=pthread_create(&pol, NULL, Sjeverni_Pol, NULL);
	if(f){
		printf("Ne mogu stvoriti dretvu!\n");
		exit(1);
	}
	pthread_join(djedo, NULL);
	pthread_join(pol, NULL);
return(0);
}



