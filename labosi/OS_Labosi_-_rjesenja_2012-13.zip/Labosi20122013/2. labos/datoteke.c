#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>

int g_br=0;
int d2_br=0;
int d3_br=0;
int html;
FILE *dat;
int brojac = 0;
int zastitnasuma = 0;
int kraj=0;
char MS[200] = {0};

void *suma (){
    int i;

    d3_br=1;
    while(kraj == 0)
    {

        while(d3_br > g_br);

        if(kraj) 
	  break;
        for(i=0; MS[i] != '\0'; i++)
            zastitnasuma^=MS[i];
        d3_br++;
    }
}

void *broji (){
    int i;
    d2_br=1;

    while (kraj !=1)
    {

        while (d2_br > g_br);

        if (kraj) 
	  break;

        if (html) 
	{
		for(i=1; MS[i] != '\0'; i++)
		{
			if ((MS[i-1]=='<') && (MS[i]!='/'))
				brojac++;
		}
	}
        if (!html)
	{
  	for(i=1; MS[i] != '\0'; i++)
	{
        	if(((MS[i]==' ') || (MS[i] == '\t')) && (MS[i-1] !=' '))
       		     brojac++;
	}
	brojac++;
	}
        d2_br++;
    }
}

void *dohvati (){
     g_br = 0;

     while(!kraj)
     {
        if(fgets(MS, sizeof(MS), dat) == NULL) 
	{
            kraj = 1;
            MS[0]='\0';
            break;
        }

        g_br++;

        while (d2_br<=g_br || d3_br <=g_br);
     }
     g_br++;

}


void analiza (char *datoteka){
    pthread_t d_thread, b_thread, s_thread;

    if (strcmp(".txt",strrchr(datoteka,'.'))==0)
        html=0;

    if (strcmp(".html",strrchr(datoteka,'.'))==0)
        html=1;

    if ((strcmp(".txt",strrchr(datoteka,'.'))) && (strcmp(".html",strrchr(datoteka,'.'))))
    {
        printf("Analiza obustavljena za datoteku \"%s\"!\n", datoteka);
        exit(-1);
    }

    dat=fopen((char*)datoteka, "r");

    if (pthread_create(&d_thread, NULL, (void*)&dohvati, NULL)) 
    {
        printf("Ne moze se stvoriti dretva 'dohvat'!");
        exit(1);
    }

    if (pthread_create(&b_thread, NULL, (void*)&broji, NULL)) 
    {               
        printf("Ne moze se stvoriti dretva 'broji'!");
        exit(1);
    }

    if (pthread_create(&s_thread, NULL, (void*)&suma, NULL)) 
    {
        printf("Ne moze se stvoriti dretva 'suma'!");
        exit(1);
    }

    pthread_join(d_thread, NULL);
    pthread_join(b_thread, NULL);
    pthread_join(s_thread, NULL);

    if (html)
        printf("Datoteka \"%s\" ima %d tagova; zastitna suma je: %d\n",datoteka, brojac, zastitnasuma);
   	 else
    	    printf("Datoteka \"%s\" ima %d rijeci; zastitna suma je: %d\n",datoteka, brojac, zastitnasuma);

    fclose(dat);
}

int main (int argc, char *argv[]){
    int i,procesi;

    for(i=1; i<argc; i++)
    {
        switch (fork())
	{
            case 0:
                analiza(argv[i]);
                exit(0);

            case -1:
                printf("Nije moguce stvoriti proces! :(");
                exit(1);

            default:
                procesi++;
        }
    }

    while (procesi--) wait(NULL);

    return 0;
}

