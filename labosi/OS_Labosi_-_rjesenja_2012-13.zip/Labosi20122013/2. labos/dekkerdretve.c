#include <stdio.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>

int ZASTAVICA[2]={0}, PRAVO=1;

void udi_u_kriticni_odsjecak(int i, int j)
{
   ZASTAVICA[i] = 1;
   while (ZASTAVICA[j] != 0)
   {
      if ( PRAVO == j )
      {
         ZASTAVICA[i] = 0;
         while ( PRAVO == j );
         ZASTAVICA[i] = 1;
      }
   }
}

void izadi_iz_kriticnog_odsjecka(int i,int j)
{
   PRAVO = j;
   ZASTAVICA[i] = 0;
}

void ispis (void * y)
{
    int i;
    i=*((int *)y);
    int k, m;
    for (k=1; k <= 5; k++)
    {
        udi_u_kriticni_odsjecak(i, 1-i);
        for (m=1; m <= 5; m++)
        {
            printf("Dretva: %d, K.O. br: %d (%d/5)\n", i+1, k, m);
            usleep(500000);
        }
        izadi_iz_kriticnog_odsjecka(i, 1-i);
    }
}

int main()
{
   int i;
   pthread_t thr_id[2];
   int broj[2] = {0, 1};

   for (i=0; i<2; i++)
        if (pthread_create(&thr_id[i], NULL, (void *)ispis, (void *)&broj[i]) != 0) {
        printf("Greska pri stvaranju dretve!\n");
        exit(1);
   }


   pthread_join(thr_id[0], NULL);
   pthread_join(thr_id[1], NULL);

   return 0;
}
