#include <iostream>
#include <list>
#include <cstdio>
#include <cstdlib>
using namespace std;

struct  zaglavlje {
	int velicina;
	int adresa;
	int slobodan;
};

int brojblokova=1, slobodni=1, zauzeti=0;
	std::list <zaglavlje> L;
	list<zaglavlje>::iterator it;

void ispis () {
	char o;
	int i=0;
	printf("RS: broj blokova = %d, slobodni = %d, zauzeti = %d\n", brojblokova, slobodni, zauzeti);
	for(it = L.begin(); it != L.end(); it++) {
		i++;
		if (it->slobodan) o='s'; else o='z';
        	printf("%d: pocetak = %d, velicina = %d, oznaka = %c   \n", i, it->adresa, it->velicina, o);
	}
	printf("\n");
}

int dodjeli (int vel) {
	int min=100000, adrmin, ad, ve, spec;
	zaglavlje z;
	for(it = L.begin(); it != L.end(); it++) {
		if (it->velicina >= vel && it->velicina < min && it->slobodan == 1) {
			min = it->velicina;
			spec = it->adresa;
		}
	}
	for(it = L.begin(); it != L.end(); it++) {
		if (it->adresa == spec) {  //vratili smo se u niz po taj s optimalnom velicinom bloka
			it++;
			if (it != L.end()) {
			if (it->slobodan == 1) { // ako je desni blok slobodan
				it--;  //ovaj blok zelim razdvojit
				adrmin = it->adresa; // ovo cu vratit
				z.velicina = vel;  // za ubacit u listu
				z.adresa = it->adresa;
				z.slobodan = 0;
				it->velicina -=vel;
				it->adresa += vel;
				L.insert(it, z);
				slobodni--;  // osvjezavanje varijabli za kasniji ispis
				zauzeti++;
				ve = it->velicina; //prikljucenje ostatka sljedecem bloku
				L.erase(it);
				it->adresa -=ve;
				it->velicina += ve;
				break;
			} else {
			it--;
			if (it != L.begin()) {
			it--;
			if (it->slobodan ==1) { //lijevi blok je slobodan
				it++;  //ovaj blok zelim razdvojit
				adrmin = it->adresa + vel;
				z.velicina = it->velicina - vel;  // za ubacit u listu
				z.adresa = it->adresa;
				z.slobodan = 1;
				it->velicina = vel;
				it->adresa += vel;
				it->slobodan = 0;
				L.insert(it, z);
				slobodni--;  // osvjezavanje varijabli za kasniji ispis
				zauzeti++;
				it--; //slobodni ostatak
				ve = it->velicina; //prikljucenje ostatka sljedecem bloku
				L.erase(it);
				it--; //blok kojemu se ostatak treba prikljuciti
				it->velicina += ve;
				break;
			} else {
			// niti lijevi niti desni blok nisu slobodni
			it++; //onaj prvotni blok
			if (it->velicina >= vel + 13) { //prvi dio ide programu, drugi dio se oslobada
				adrmin = it->adresa; // ovo cu vratit
				z.velicina = vel;  // za ubacit u listu
				z.adresa = it->adresa;
				z.slobodan = 0;
				it->velicina -=vel;
				it->adresa += vel;
				L.insert(it, z);
				zauzeti++; // osvjezavanje varijabli za kasniji ispis
				brojblokova++;
				break;
			} else { // nema dovoljno mjesta za dijeljenje - daje se cijeli blok
				adrmin = it->adresa;
				it->slobodan = 0;
				slobodni--;
				zauzeti++;
				break;
			}
			}

			} else { //kraj slucaja kad nije na pocetku, znaci tu je na pocetku, a nije na kraju
			it++;
			if (it->slobodan == 1) { // na pocetku je, a slijedeci je slobodan
				adrmin = it->adresa; // ovo cu vratit
				z.velicina = vel;  // za ubacit u listu
				z.adresa = it->adresa;
				z.slobodan = 0;
				it->velicina -=vel;
				it->adresa += vel;
				L.insert(it, z);
				slobodni--;  // osvjezavanje varijabli za kasniji ispis
				zauzeti++;
				ve = it->velicina; //prikljucenje ostatka sljedecem bloku
				L.erase(it);
				it->adresa -=ve;
				it->velicina += ve;
				break;
			} else {
				it--;
				if (it->velicina >= vel + 13) { //prvi dio ide programu, drugi dio se oslobada
					adrmin = it->adresa; // ovo cu vratit
					z.velicina = vel;  // za ubacit u listu
					z.adresa = it->adresa;
					z.slobodan = 0;
					it->velicina -=vel;
					it->adresa += vel;
					L.insert(it, z);
					zauzeti++; // osvjezavanje varijabli za kasniji ispis
					brojblokova++;
					break;
				} else { // nema dovoljno mjesta za dijeljenje - daje se cijeli blok
					adrmin = it->adresa;
					it->slobodan = 0;
					slobodni--;
					zauzeti++;
					break;
			}


			}


			}

			}

			} else { // kraj slucaja kad nije na kraju samom, znaci NA KRAJU SMO
			it--; // to je onaj
			if (it == L.begin()) { // na kraju smo i na pocetku (samo je 1 element)
				adrmin = it->adresa; // ovo cu vratit
				z.velicina = vel;  // za ubacit u listu
				z.adresa = it->adresa;
				z.slobodan = 0;
				it->velicina -=vel;
				it->adresa += vel;
				L.insert(it, z);
				zauzeti++;  // osvjezavanje varijabli za kasniji ispis
				brojblokova++;
				break;
			} else {  // na kraju smo, a ne na pocetku
			it--;
			if (it->slobodan) {  // na kraju smo, lijevi blok je slobodan
				adrmin = it->adresa + vel;
				z.velicina = it->velicina - vel;  // za ubacit u listu
				z.adresa = it->adresa;
				z.slobodan = 1;
				it->velicina = vel;
				it->adresa += vel;
				it->slobodan = 0;
				L.insert(it, z);
				slobodni--;  // osvjezavanje varijabli za kasniji ispis
				zauzeti++;
				it--; //slobodni ostatak
				ve = it->velicina; //prikljucenje ostatka sljedecem bloku
				L.erase(it);
				it--; //blok kojemu se ostatak treba prikljuciti
				it->velicina += ve;
				break;
			} else { // na kraju smo, a lijevi nije slobodan
				it++;
				if (it->velicina >= vel + 13) { //prvi dio ide programu, drugi dio se oslobada
					adrmin = it->adresa; // ovo cu vratit
					z.velicina = vel;  // za ubacit u listu
					z.adresa = it->adresa;
					z.slobodan = 0;
					it->velicina -=vel;
					it->adresa += vel;
					L.insert(it, z);
					zauzeti++; // osvjezavanje varijabli za kasniji ispis
					brojblokova++;
					break;
				} else { // nema dovoljno mjesta za dijeljenje - daje se cijeli blok
					adrmin = it->adresa;
					it->slobodan = 0;
					slobodni--;
					zauzeti++;
					break;
			}
			}

			}


			}
		}
	}
return adrmin;
}

void oslobodi (int adr) {
	int ve, ad, rjesen=0;
	for(it = L.begin(); it != L.end(); it++) {
		if (it->adresa == adr) {
			if (it != L.begin()) {
				it++;
				if (it != L.end()) {
					it--;
					it--; //do bloka prije oslobadanja
					if (it->slobodan == 1) { // blok prije je slobodan
						it++; it++;
						if (it->slobodan ==1) { // blok iza je isto slobodan
							rjesen=1;
							ve = it->velicina;
							L.erase(it);
							it--;
							ve+=it->velicina;
							L.erase(it);
							it--;
							it->velicina +=ve;
							slobodni--;
							zauzeti--;
							brojblokova-=2;
						} else {
						it--; //samo ovaj lijevo je slobodan
						rjesen=1;
						ve = it->velicina;
						L.erase(it);
						it--;
						it->velicina +=ve;
						zauzeti--;
						brojblokova--;
						}
					} else {
						it++;
						it++;
						if (it->slobodan == 1) { // samo blok desno je slobodan
							rjesen=1;
							ve= it->velicina;
							L.erase(it);
							it--;
							it->velicina +=ve;
							it->slobodan = 1;
							zauzeti--;
							brojblokova--;
						} else { // niti blok lijevo niti blok desno nisu slobodni
							it--;
							rjesen=1;
							it->slobodan = 1;
							zauzeti--;
							slobodni++;
						}

					}


				} else {
				it--; //bio je kraj liste, dolazimo natrag na zadnji element
				it--; //1 prije njega
				if (it->slobodan == 1) { //lijevo je slobodan blok
					it++; //onaj pravi
					rjesen=1;
					ve=it->velicina;
					L.erase(it);
					it--;
					it->velicina +=ve;
					zauzeti--;
					brojblokova--;
				}
				else {
					it++;
					rjesen=1;
					it->slobodan=1;
					slobodni++;
					zauzeti--;
				}
				}

			} else { // pocetak je liste, ima smisla gledati samo desni blok
				it++;
				if (it->slobodan == 1) { // desno od njega je slobodan
						rjesen=1;
						ve= it->velicina;
						L.erase(it);
						it--;
						it->velicina +=ve;
						it->slobodan = 1;
						zauzeti--;
						brojblokova--;
				} else it--;
			}
			if (rjesen == 0) {
				it->slobodan = 1;
				zauzeti--;
				slobodni++;
			}
		break;
		}
	}


}

int main() {
	int vel;
	char c[5];
	/*zaglavlje *blok;

	blok = (zaglavlje *) malloc(sizeof(zaglavlje));
	blok->velicina = 10000;
	blok->adresa = 0;
	blok->slobodan = 1;
	L.push_back(*blok); */
	zaglavlje blok;

	L.clear();
	blok.velicina = 10000;
	blok.adresa = 0;
	blok.slobodan = 1;
	it=L.begin();
	L.insert(it, blok);

	ispis();

	while (1) {
		printf("Unesi zahtjev (d-dodijeli, o-oslobodi):");
		scanf("%s", c);
		if (c[0] == 'd') {
			printf("Unesi velicinu programa (u oktetima):");
			scanf("%d", &vel);
			printf("Dodjeljen je blok na adresi %d\n\n", dodjeli(vel+12));
		} else
		if (c[0] == 'o') {
			printf("Unesi pocetnu adresu programa:");
			scanf("%d", &vel);
            printf("\n");
			oslobodi(vel);
		}
		ispis();
	}
	return 0;
}
