#include <stdio.h>
#include <time.h>
#include <stdlib.h>

struct st {
	int time,broj;
};

typedef struct st okvir;

okvir niz[10];
int zahtjevi[100];
int brojo, brojz;
int main(int argc, char *argv[]){
int i, j, k, vrijeme=0, min= 1000000, rjeseno;

srand((unsigned) time (NULL));

sscanf(argv[1], "%d", &brojo);
sscanf(argv[2], "%d", &brojz);
//brojo=4;
//brojz=10;

for (i=0; i < brojo; i++) {
	niz[i].time = 1000000;
	niz[i].broj = 0;
}

printf("Zahtjevi: ");
for(i=0;i<brojz - 1;i++){
	zahtjevi[i]=(rand()%8) +1;
	printf("%d, ", zahtjevi[i]);
}
zahtjevi[brojz-1] = (rand()%8) +1;
printf("%d\n", zahtjevi[brojz-1]);

printf("#N  ");
for (i=1; i <= brojo; i++)
	printf("%d   ", i);
printf("\n------------------\n");

for (i=0; i<brojz; i++) {
    rjeseno=0;
	for (j=0; j< brojo; j++) {
		if (niz[j].broj == zahtjevi[i]) {
		    rjeseno=1;
			vrijeme++;
			niz[j].time = vrijeme;
			niz[j].broj = zahtjevi[i];
			printf("%d  ", zahtjevi[i]);
			for(k=0; k < brojo; k++) {
				if (k == j) printf("(%d) ", niz[k].broj);
					else if (niz[k].broj == 0) printf(" -  ");
						else printf(" %d  ", niz[k].broj);
			}
            printf("   #pogodak\n");
			break;
		}
	}
    if (rjeseno == 0) {
	for (j=0; j< brojo; j++)
		if (niz[j].broj == 0 ) {
		    rjeseno =1;
			vrijeme++;
			niz[j].time = vrijeme;
			niz[j].broj = zahtjevi[i];
			printf("%d  ", zahtjevi[i]);
			for(k=0; k < brojo; k++) {
				if (k == j) printf("[%d] ", niz[k].broj);
					else if (niz[k].broj == 0) printf(" -  ");
						else printf(" %d  ", niz[k].broj);
			}
			printf("\n");
			break;
		}
	}
    if (rjeseno == 0) {
		min = 0;
		for(k=0; k < brojo; k++)
			if (niz[k].time < niz[min].time) min = k;
		vrijeme++;
		niz[min].time = vrijeme;
		niz[min].broj = zahtjevi[i];
		printf("%d  ", zahtjevi[i]);
		for(k=0; k < brojo; k++) {
			if (k == min) printf("[%d] ", niz[k].broj);
				else if (niz[k].broj == 0) printf(" -  ");
					else printf(" %d  ", niz[k].broj);
			}
        printf("\n");
	}
}
return 0;
}
