#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <time.h>

int br_sobova=0; // broj sobova pred vratima
int br_patuljaka=0; // broj patuljaka pred vratima
int napravljeni_sobovi=0;
int K=0; //1
int djedbozicnjak=1; // 0
int konzultacije=2; //3
int sobovi=3; //0
int SemId, Id;

void SemGet(int n){
   SemId = semget(IPC_PRIVATE, n, 0600);
   if (SemId == -1) {
      printf("Nema semafora!\n");
      exit(1);
   }
}

int SemSetVal(int SemNum, int SemVal){  
   return semctl(SemId, SemNum, SETVAL, SemVal);
}

int SemOp(int SemNum, int SemOp) {  
   struct sembuf SemBuf;
   SemBuf.sem_num = SemNum;
   SemBuf.sem_op  = SemOp;
   SemBuf.sem_flg = 0;
   return semop(SemId, & SemBuf, 1);
}

void SemRemove(int sig) { 
   (void) semctl(SemId, 0, IPC_RMID, 0);
}

void brisi (int sig){
     /*(void) shmdt((int *) ULAZ);
     (void) shmdt((int *) IZLAZ);
     (void) shmdt((int *) ms); */
     (void) shmctl(Id, IPC_RMID, NULL);
     exit(0);
     }

void Djed() {
	while (1) {
		SemOp(djedbozicnjak, -1);
		SemOp(K, -1);
		if (br_sobova == 10 && br_patuljaka > 0) {
			SemOp(K, 1);
			sleep(2);
			printf("Ukrcavaju se pokloni, sobovi spremaju za let i raznose se pokloni djeci sirom svijeta!\n");
			SemOp(K, -1);

			SemOp(sobovi, 10); //povećaj semafor za 10
			br_sobova -= 10;
		}
		if (br_sobova == 10) {
			SemOp(K, 1);
			sleep(2);
			printf("Hrane se gladni sobici :)\n");
			br_sobova=0;
			SemOp(K, -1);
		}
		//ako je samo_tri_patuljka_pred_vratima 
		while (br_patuljaka >= 3) {
			SemOp(K, 1);
			sleep(2);
			printf("Rjesavaju se problemi patuljaka\n");
			SemOp(K, -1);

			SemOp(konzultacije, 3); //povećaj semafor za 3
			br_patuljaka -= 3;
		}
		SemOp(K, 1);
	}
}

void Patuljak() {
	SemOp(K, -1);
	printf("Patuljak%d kaze: Ja sam dosao!\n", (br_patuljaka % 3) + 1);
	br_patuljaka++;
	if (br_patuljaka == 3) {//ovaj je treći
		SemOp(djedbozicnjak, 1);
	} 
	SemOp(K, 1);
	SemOp(konzultacije, br_patuljaka-3);
}
 
void Sob () {
	time_t sec;
	time(&sec);
	srand((unsigned int) sec);
	int igrajseupolju;
	while (1) {
		SemOp(K, 1);
		printf("Sob%d kaze: Ja sam gladan, a i spreman sam za raznosenje poklona!\n", (br_sobova % 10) + 1);
		br_sobova++;
		if (br_sobova == 10)
			SemOp(djedbozicnjak, 1);
		SemOp(sobovi, -1);
		igrajseupolju= (rand() % 30) + 1; // godisnji
		sleep(igrajseupolju);
	}
}

int main () {
	int vrijeme;
	int pat;
	int sob;
	int j;
	int k;
	int i[3] = {0, 1, 3};
	pthread_t thr_id[100];
	int br_dretvi=1;
	time_t sec;
	time(&sec);


	srand((unsigned int) sec);

	sigset(SIGINT, brisi);

	SemGet(4);
	SemSetVal(K,i[1]); //1
	SemSetVal(djedbozicnjak,i[0]); //0
	SemSetVal(konzultacije,i[2]); //3
	SemSetVal(sobovi,i[0]); //0

	if (pthread_create(&thr_id[0], NULL, (void *)Djed, NULL) != 0) {
        		printf("Greska pri stvaranju dretve!\n");
        		exit(1);
			}

	while (1) {
		vrijeme= (rand() % 3) + 1; //od 1 do 3 sekunde
		sleep(vrijeme);
		sob= rand() % 2;
		if (sob && napravljeni_sobovi < 10 && br_dretvi < 99) {
			if (pthread_create(&thr_id[br_dretvi], NULL, (void *)Sob, NULL) != 0) {
        		printf("Greska pri stvaranju dretve!\n");
        		exit(1);
			}
			br_dretvi++;
		}
		pat = rand() % 2;
		if (pat && br_dretvi < 99){
			if (pthread_create(&thr_id[br_dretvi], NULL, (void *)Patuljak, NULL) != 0) {
        		printf("Greska pri stvaranju dretve!\n");
        		exit(1);
			}
			br_dretvi++;
		}
	}

	for(k=0; k< 100; k++)
		pthread_join(thr_id[k], NULL);

	return 0;
}

