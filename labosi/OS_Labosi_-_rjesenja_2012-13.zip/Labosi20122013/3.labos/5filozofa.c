#include <stdio.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>

char filozof[5] = {'O', 'O', 'O', 'O', 'O'};
int vilica[5]= {1, 1, 1, 1, 1};
pthread_mutex_t M;
pthread_cond_t uv[5];

void udi_u_KO () {
   pthread_mutex_lock(&M);
}

void izadi_iz_KO () {
   pthread_mutex_unlock(&M);
}

void jesti (int n) {
   udi_u_KO();
      filozof[n] = 'o';
      while (vilica[n] == 0 || vilica[(n + 1) % 5] == 0)
         pthread_cond_wait(&uv[n], &M);
      vilica[n] = vilica[(n + 1) % 5] = 0;
      filozof[n] = 'X';
      printf("%c %c %c %c %c (%d)\n", filozof[0], filozof[1], filozof[2], filozof[3], filozof[4], n+1);
   izadi_iz_KO();

   sleep(2);

   udi_u_KO();
      filozof[n] = 'O';
      vilica[n] = vilica[(n + 1) % 5] = 1;
      pthread_cond_signal(&uv[(n - 1) % 5]);
      pthread_cond_signal(&uv[(n + 1) % 5]);
      printf("%c %c %c %c %c (%d)\n", filozof[0], filozof[1], filozof[2], filozof[3], filozof[4], n+1);
   izadi_iz_KO();
}

void dretva_filozof ( void * i) {
   while (1) {
	sleep(2); // misliti
	jesti(*((int *) i));
   }
}

int main() {
   int i;
   pthread_t thr_id[5];
   int broj[5] = {1, 2, 3, 4, 5};

   pthread_mutex_init(&M, NULL);
   pthread_cond_init (uv,NULL);

   for (i=0; i<5; i++)
        if (pthread_create(&thr_id[i], NULL, (void *)dretva_filozof, (void *)&broj[i]) != 0) {
        printf("Greska pri stvaranju dretve!\n");
        exit(1);
   }

   pthread_join(thr_id[0], NULL);
   pthread_join(thr_id[1], NULL);
   pthread_join(thr_id[2], NULL);
   pthread_join(thr_id[3], NULL);
   pthread_join(thr_id[4], NULL);

   return 0;
}
