#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

int SemId;
int Id;
int *ULAZ;
int *IZLAZ;
int pom1=3;
int pom2=4; 
typedef struct{
  char M[5];
}MS;
MS *ms;

void SemGet(int n){
   SemId = semget(IPC_PRIVATE, n, 0600);
   if (SemId == -1) {
      printf("Ne mogu dobiti semafore!\n");
      exit(1);
   }
}

int SemSetVal(int SemNum, int SemVal){  
   return semctl(SemId, SemNum, SETVAL, SemVal);
}

int SemOp(int SemNum, int SemOp) {  
   struct sembuf SemBuf;
   SemBuf.sem_num = SemNum;
   SemBuf.sem_op  = SemOp;
   SemBuf.sem_flg = 0;
   return semop(SemId, & SemBuf, 1);
}

void SemRemove(int sig) { 
   (void) semctl(SemId, 0, IPC_RMID, 0);
}

 void proizvodac (int ja) {
      char poruka[25];
      int j=0;
      SemOp(pom1,-1);
      printf("Unesi znakove za proizvodaca %d:",ja+1);
      scanf("%s",poruka); 
      SemOp(pom1,1);
      if(ja==0)
      SemOp(pom2,-1);
      else
      SemOp(pom2,1); 
      do {   
         SemOp(1,-1);  // PUN
         SemOp(0,-1);    // PISI
          ms->M[*ULAZ]=poruka[j];
          printf("PROIZVODAC%d -> %c \n", ja+1, ms->M[*ULAZ]);
          *ULAZ=(*ULAZ+1)%5;
          SemOp(0,1); // PISI
          SemOp(2,1); // PRAZAN
          j=j+1;
        } while(poruka[j-1]!='\0');
}

 void potrosac(){
  char poruka[50];
  int i=0;
  int oznakekraja=0;
  do{
   SemOp(2,-1);  // PRAZAN
   if (ms->M[*IZLAZ] == '\0') {
	oznakekraja++;
	if (oznakekraja == 1) {
		printf("POTROSAC <- %c\n",ms->M[*IZLAZ]);
		*IZLAZ=(*IZLAZ+1)%5;
		SemOp(1,1); // PUN
		continue;
	}
  }
   printf("POTROSAC <- %c\n",ms->M[*IZLAZ]);  
   poruka[i]=ms->M[*IZLAZ];
   *IZLAZ=(*IZLAZ+1)%5;
   SemOp(1,1); // PUN
   i=i+1;
   }

   while(oznakekraja!=2);    
   printf("Primljeno je %s\n",poruka);
}

void brisi (int sig){
     (void) shmdt((char *) ULAZ);
     (void) shmdt((char *) IZLAZ);
     (void) shmdt((char *) ms);
     (void) shmctl(Id, IPC_RMID, NULL);
     exit(0);
     }


int main(int argc, char *argv[])
{
  int ja, i;
  SemGet(5);

  Id=shmget(IPC_PRIVATE,sizeof(int)*100,0600);
  if(Id==-1) {
       printf("Dogodila se greska! Ne mogu dobiti zajednicku memoriju!");
       exit (1);
  }

  sigset(SIGINT,brisi);
  sigset(SIGINT, SemRemove);

  ULAZ=(int *)shmat(Id,NULL,0);
  IZLAZ=(int *)shmat(Id,NULL,0)+1;
  ms=(MS *)shmat(Id,NULL,0)+2;

  *ULAZ=0;
  *IZLAZ=0;
  for(i = 0; i < 5; i++)
    ms->M[i]=0;
  
  SemSetVal(pom1,1); // stiti ulaz
  SemSetVal(pom2,0); // stiti da jedna dretva ne krene slati poruku dok druga ne dobije svoju poruku
  SemSetVal(0,1); // PISI
  SemSetVal(2,0); // PRAZAN
  SemSetVal(1,5); // PUN

   if (fork() == 0) {
      proizvodac(ja);
      exit(0);
   }
   ja=1;
   if (fork() == 0) {
      proizvodac(ja);
      exit(0);
   }
   if (fork() == 0) {
      potrosac();
      exit(0);
   }

   (void) wait(NULL);
   (void) wait(NULL);
   (void) wait(NULL);

  return 0;
}

