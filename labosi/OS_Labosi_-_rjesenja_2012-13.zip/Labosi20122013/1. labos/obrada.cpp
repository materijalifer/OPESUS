#include <iostream>
#include <csignal>
#include <cstdio>
#define N 6

using namespace std;

int OZNAKA_CEKANJA[N]= {0};
int PRIORITET[N]={0};
int TEKUCI_PRIORITET=0;

int sig [5]={SIGUSR1, SIGUSR2, SIGHUP, SIGPIPE, SIGINT};

void zabrani_prekidanje ()
{
	int i;
	for (i=0; i < 5; i++)
		sighold(sig[i]);
}

void dozvoli_prekidanje()
{
	int i;
	for (i=0; i < 5; i++)
		sigrelse(sig[i]);
}

void obrada_prekida(int i)
{
	int j, k;
	printf(" ");
	for (j=0; j < 6; j++) {
	if (j == i) 
		printf("P  ");
	else printf("-  ");
	}
	printf("\n");

	for (j=1; j < 6; j++) {
	sleep(1);
	printf(" ");
	for (k=0; k < 6; k++)
	if (k == i) 
		printf("%d  ", j);
	else 
		printf("-  ");
	printf("\n");
	}
	
	printf(" ");
	for (j=0; j < 6; j++)
	if (j == i) 
		printf("K  ");
	else 
		printf("-  ");
	printf("\n");
}

void prekidna_rutina(int sig)
{
	int n=1;
	int x, j;
	zabrani_prekidanje();
	switch (sig) {
		case SIGUSR1:
			n=1;
			printf(" -  X  -  -  -  -\n");
			break;
		case SIGUSR2:
			n=2;
			printf(" -  -  X  -  -  -\n");
			break;
		case SIGHUP:
			n=3;
			printf(" -  -  -  X  -  -\n");
			break;
		case SIGPIPE:
			n=4;
			printf(" -  -  -  -  X  -\n");
			break;
		default:
			n=5;
			printf(" -  -  -  -  -  X\n");
	}

	OZNAKA_CEKANJA[n]=1;

	do {
		x=0;
		for (j=TEKUCI_PRIORITET+1; j < N; j++) {
			if (OZNAKA_CEKANJA[j] != 0 )
				x=j;
		}
		if (x > 0) {
			OZNAKA_CEKANJA[x] = 0;
			PRIORITET[x] = TEKUCI_PRIORITET;
			TEKUCI_PRIORITET = x;
			dozvoli_prekidanje();
			obrada_prekida(x);
			zabrani_prekidanje();
			TEKUCI_PRIORITET = PRIORITET [x];
		} 

		dozvoli_prekidanje();

	} while (x > 0);
}

int main() {
	int p=0, i=0;
	sigset (SIGUSR1, prekidna_rutina);
	sigset (SIGUSR2, prekidna_rutina);
	sigset (SIGHUP, prekidna_rutina);
	sigset (SIGPIPE, prekidna_rutina);
	sigset (SIGINT, prekidna_rutina);

	printf("Proces obrade prekida, PID=%d\n", getpid());
	printf("GP S1 S2 S3 S4 S5\n-----------------\n");
	for(i=0; i < 30; i++) {
	printf("%2d  -  -  -  -  -\n", i);
	sleep(1);
	}

	printf("Zavrsio osnovni program\n");

	return 0;
}

