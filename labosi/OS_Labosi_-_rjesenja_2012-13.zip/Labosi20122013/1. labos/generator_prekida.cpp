#include <cstdio>
#include <csignal>
#include <cstdlib>
#include <iostream>

using namespace std;

int pid=0;

void prekidna_rutina (int sig) 
{
	kill (pid, SIGKILL);
	exit(0);
}

int main (int argc, char *argv[]) {
	int i=0;
	pid=atoi(argv[1]);
	sigset (SIGINT, prekidna_rutina);

	while (1) {
	i= 3 + (rand() % 3);
	sleep(i);
	i= 1 + (rand() % 4);
	switch (i) {
		case 1: kill (pid, SIGUSR1);
			break;
		case 2: kill (pid, SIGUSR2);
			break;
		case 3: kill (pid, SIGHUP);
			break;
		default: kill (pid, SIGPIPE);
		}
    }
}
	
