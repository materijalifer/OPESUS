#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <signal.h>
#include <time.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define LIJEVA 0
#define DESNA 1
#define MISIONARI 0
#define KANIBALI 1
#define ISKRCAN 0
#define UKRCAN 1
#define PLOVI 2

int kljuc=0;
int camac_poz;
int prazan_camac=1;
int camac_misionari=0;
int camac_kanibali=0;
int obala_misionari[2]={0};
int obala_kanibali[2]={0};
pthread_cond_t uvjet[2][2];
pthread_cond_t camac[3];
pthread_mutex_t m;
pthread_t dretva[4];
int broj_dretvi=2;

void stvoren(int osoba, int obala)
{
	if(osoba==MISIONARI)
		if(obala==LIJEVA)
			printf("Stvoren misionar na lijevoj obali.\n");
		else
			printf("Stvoren misionar na desnoj obali.\n");
	else
		if(obala==DESNA)
			printf("Stvoren kanibal na desnoj obali.\n");
		else
			printf("Stvoren kanibal na lijevoj obali.\n");
}

void *misionar(void *x){
	int obala,usao=0;
	obala=*((int*)x);
	pthread_mutex_lock(&m);
	obala_misionari[obala]++;
	stvoren(MISIONARI, obala);
	while(usao==0){
		if(camac_poz==obala && (camac_kanibali+camac_misionari)<7 && camac_kanibali<=(camac_misionari+1)){
			camac_misionari++;
			obala_misionari[obala]--;
			usao=1;
			printf("Misionar je usao u camac %d\n",obala);

			if((camac_misionari+camac_kanibali)==3){ 
				pthread_cond_signal(&camac[UKRCAN]);
				printf("Camac je ukrcan\n");
			}
			if((camac_misionari+camac_kanibali)<7 && (obala_kanibali[obala])>0)
				pthread_cond_signal(&uvjet[obala][KANIBALI]);
		}
		else
		{
			pthread_cond_wait(&uvjet[obala][MISIONARI],&m);
		}
	}
	
	pthread_cond_wait(&camac[PLOVI],&m);
	camac_misionari--;
	printf("Misionar je izasao iz camca\n");
	if((camac_kanibali+camac_misionari)==0){
		printf("Camac je iskrcan\n");
		pthread_cond_signal(&camac[ISKRCAN]);
	}
	pthread_mutex_unlock(&m);
	pthread_join(dretva[3], NULL);
	return 0;
}
     
void *kanibal(void *x){
	int obala,usao=0;
	obala=*((int*)x);
	pthread_mutex_lock(&m);
	obala_kanibali[obala]++;
	stvoren(KANIBALI, obala);
	while(usao==0){
		if(obala==camac_poz && (camac_kanibali+camac_misionari)<7 && (camac_kanibali+1)<=camac_misionari){
			camac_kanibali++;
			obala_kanibali[obala]--;
			usao=1;
			printf("Kanibal je usao u camac %d\n", obala);

			if((camac_kanibali+camac_misionari)==3){  
				pthread_cond_signal(&camac[UKRCAN]);
				printf("Camac je ukrcan\n");
			}
			if((camac_misionari+camac_kanibali)<7 && obala_misionari[obala]>0)
				pthread_cond_signal(&uvjet[obala][MISIONARI]);
		}
		else
		{
			pthread_cond_wait(&uvjet[obala][KANIBALI],&m);
		}
	}
	
	pthread_cond_wait(&camac[PLOVI],&m);

	camac_kanibali--;
	printf("Kanibal je izasao iz camca\n");

	if((camac_kanibali+camac_misionari)==0){
		printf("Camac je iskrcan\n");
		pthread_cond_signal(&camac[ISKRCAN]);
		
	}
	pthread_mutex_unlock(&m);
	pthread_join(dretva[2], NULL);
	return 0;
}

void *stvori_putnike(){
	int i;
	while(1){
		while (kljuc==1);
		i=rand()%2;
		if(pthread_create(&dretva[2], NULL, kanibal,(void*) &i)!=0)exit(1);
	
		sleep(1);

		i=rand()%2;
		if(pthread_create(&dretva[3], NULL, misionar,(void*) &i)!=0)exit(1);

		i=rand()%2;
		if(pthread_create(&dretva[2], NULL, kanibal,(void*) &i)!=0)exit(1);

		sleep(1);
	}    
}
     
void *camac_d(){
	camac_poz=DESNA;
    pthread_mutex_lock(&m);
    while(1){
	pthread_cond_wait(&camac[UKRCAN],&m);   
	kljuc=1;     
	sleep(1);
        printf("\nCamac prelazi obalu\n\n");
        sleep(1);
	camac_poz=abs(1-camac_poz);
	pthread_cond_broadcast(&camac[PLOVI]);
        pthread_cond_wait(&camac[ISKRCAN],&m);
	kljuc=0;
	while ((camac_kanibali+camac_misionari)!=0);
        pthread_cond_broadcast(&uvjet[camac_poz][MISIONARI]);
        pthread_cond_broadcast(&uvjet[camac_poz][KANIBALI]);
    }
    pthread_mutex_unlock(&m);
}
     
int main(){
	srand((unsigned)time(NULL));
	pthread_mutex_init(&m, NULL);
	pthread_cond_init(&uvjet[0][0], NULL);
	pthread_cond_init(&uvjet[0][1], NULL);
	pthread_cond_init(&uvjet[1][0], NULL);
	pthread_cond_init(&uvjet[1][1], NULL);
	pthread_cond_init(&camac[UKRCAN], NULL);
	pthread_cond_init(&camac[ISKRCAN], NULL);
	pthread_cond_init(&camac[PLOVI], NULL);
	int i;
	
	

	if(pthread_create(&dretva[0], NULL, stvori_putnike, NULL)!=0)exit(1);
	if(pthread_create(&dretva[1], NULL, camac_d, NULL)!=0)exit(1);

	
	for(i=0; i<2; i++){
		pthread_join(dretva[i], NULL);
	}
	return 0;
}
