#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <unistd.h>
#include <sys/wait.h>

int semafori, Id;

int SemSetVal(int SemNum, int SemVal)
{
   return semctl(semafori, SemNum, SETVAL, SemVal);
}

int SemOp(int SemNum, int SemOp)
{
   struct sembuf SemBuf;
   SemBuf.sem_num = SemNum;
   SemBuf.sem_op  = SemOp;
   SemBuf.sem_flg = 0;
   return semop(semafori, & SemBuf, 1);
}
void brisisem(int sig) {
        (void) semctl(semafori, 0, IPC_RMID, 0);
}


void brisi (int sig){
     	(void) shmctl(Id, IPC_RMID, NULL);
	brisisem(1);
     	exit(0);
     }


void trgov(){
	srand ((unsigned) time(NULL));
	int x;
	while (1){
		SemOp(0,-1);
		x=rand()%3+1;
		SemOp(x,1);
		}
}

void sib(){while(1){
	SemOp(1,-1);
	printf ("Trgovac stavlja: papir i duhan\nPusac 1: uzima sastojke i mota.\n\n");
	SemOp(0,1);
	sleep(1);
}
}
void duh(){while(1){
        SemOp(2,-1);
        printf ("Trgovac stavlja: sibice i papir\nPusac 2: uzima sastojke i mota.\n\n");
	sleep(1);
	SemOp(0,1);
}
}
void pap(){while (1){
        SemOp(3,-1);
        printf ("Trgovac stavlja: sibice i duhan\nPusac 3: uzima sastojke i mota.\n\n");
	sleep(1);
	SemOp(0,1);
}
}

int main(){
	printf ("\nPusac 1: ima sibice\nPusac 2: ima duhan\nPusac 3: ima papir\n");
    	int i=0;
	semafori = semget(IPC_PRIVATE, 4, 0600);
   	if (semafori==-1) {
      		printf("Ne mogu stvoriti semafore\n");
      		exit(1);
   			}

	Id=shmget(IPC_PRIVATE,sizeof(int)*100,0600);
  	if(Id==-1)
       		exit (1);
	sigset(SIGINT,brisi);

	SemSetVal(0,1);
	SemSetVal(1,0);
	SemSetVal(2,0);
	SemSetVal(3,0);

	switch (fork()) {
   		case 0: trgov();
	        	exit(0);
   		case -1:printf("Nije moguce stvoriti proces!\n");
			exit(-1);
	}i++;
	switch (fork()) {
                case 0: sib();
                        exit(0);
                case -1:printf("Nije moguce stvoriti proces!\n");
                        exit(-1);
        }i++;
	switch (fork()) {
                case 0: duh();
                        exit(0);
                case -1:printf("Nije moguce stvoriti proces!\n");
                        exit(-1);
        }i++;
	switch (fork()) {
                case 0: pap();
                        exit(0);
                case -1:printf("Nije moguce stvoriti proces!\n");
                        exit(-1);
        }i++;
	while(i){
		wait (NULL);
	        brisi(0);
		i--;
	}

	return 0;
}