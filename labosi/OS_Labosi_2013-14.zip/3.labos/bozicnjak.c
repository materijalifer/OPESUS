#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

int br_sobova, br_patuljaka;
void *sobovi();
void *patuljci();
pthread_cond_t djedmraz;
pthread_cond_t konzultacije;
pthread_cond_t sobovi_red;
pthread_mutex_t mon;

void *Sjeverni_Pol(){
	int t, vj_pom, vj_sob;
	pthread_t thr_id[2];
	while (1){
		t=rand()%3+1;
		sleep(t);
		vj_pom=rand()%101;
		vj_sob=rand()%101;
		if (vj_sob>50 && br_sobova<10){
			if (pthread_create(&thr_id[0], NULL,sobovi, NULL)){
				printf("Nova se dretva ne moze stvoriti!\n");
        			exit(1);
			}
		}
		if(vj_pom>50){
       			 if(pthread_create(&thr_id[1],NULL,patuljci,NULL)){
       		 	 	printf("Nova se dretva ne moze stvoriti!\n");
       				exit(1);
       			 }
		}
	}
}

void *Djed_Mraz(){
	int i;
	pthread_mutex_lock (&mon);
        while (1){
                pthread_cond_wait (&djedmraz, &mon);
		if (br_sobova==10 && br_patuljaka!=0){
                        	printf("Razvozi poklone.\n");
                        	sleep(2);
                       		pthread_cond_broadcast (&sobovi_red);
                        	br_sobova=0;
                }
		if (br_sobova==10 && br_patuljaka==0){
				printf ("Hrani sobove.\n");
				sleep(2);
		}
		while (br_patuljaka>=3){
			printf("Rjesava problem patuljaka.\n");
			for (i=0;i<3;i++)
				pthread_cond_signal(&konzultacije);
			br_patuljaka-=3;
		}
	}
	pthread_mutex_unlock (&mon);
}

void *patuljci (){
	pthread_mutex_lock (&mon);
	br_patuljaka++;
	printf ("Broj patuljaka pred vratima je: %d\n", br_patuljaka);
	if (br_patuljaka==3)
		pthread_cond_signal(&djedmraz);
	pthread_cond_wait (&konzultacije,&mon);
	pthread_mutex_unlock (&mon);
}

void *sobovi(){
	int i;
	br_sobova++;
	printf("Broj sobova pred vratima: %d\n", br_sobova);
	if(br_sobova==10)
		pthread_cond_signal (&djedmraz);
}

int main (){
	srand ((unsigned) time(NULL));
	int x=0;
	pthread_t thr_id[2];
	pthread_mutex_init (&mon,NULL);
        pthread_cond_init (&djedmraz,NULL);
        pthread_cond_init (&sobovi_red,NULL);
        pthread_cond_init (&konzultacije,NULL);

    	if (pthread_create(&thr_id[0],NULL,Djed_Mraz,NULL)){
        	printf("Nova se dretva ne moze stvoriti.\n");
        	exit(1);
        }
    	if (pthread_create(&thr_id[1],NULL,Sjeverni_Pol,NULL)){
        	printf("Nova se dretva ne moze stvoriti.\n");
        	exit(1);
        }
   	while(x<2){
   		 pthread_join(thr_id[x],NULL);
   		 x++;
   	}
	return 0;
}