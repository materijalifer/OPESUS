#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <values.h>

int pravo=0;
int z[2]={0};

void KO_ulaz (int a, int b);
void KO_izlaz (int a, int b);

void *izvrsi (void *i) {
	int a, b, m;
	m=((int)i+1)%2;
	for (a=1; a<=5; a++){
		KO_ulaz ((int) i, m);
		for (b=1; b<=5; b++){
		printf ("Dretva: %d, K.O. br: %d (%d/5)\n",(int)i+1, a, b);
		sleep (1);
		}
	KO_izlaz ((int)i, m);
	}
}

void KO_ulaz (int a, int b){
	int x;
	z[a]=1;
	while (z[b]!=0){
		if (pravo==b){
			z[a]=0;
			while (pravo==b)
			x=1;
			z[a]=1;
		}
	}
}

void KO_izlaz(int a, int b){
pravo=b;
z[a]=0;
}

int main (int argc, char *argv[]){
int x=0;
pthread_t thr_id[2];
do {
	if ((pthread_create(&thr_id[x], NULL,(void *) izvrsi,(void *) x))!=0){
	printf ("Ne mogu stvoriti dretvu!");
	exit (1);
	}
	sleep (1);
	x++;
} while (x<2);

pthread_join(thr_id[0], NULL);
pthread_join(thr_id[1], NULL);

return 0;
}
