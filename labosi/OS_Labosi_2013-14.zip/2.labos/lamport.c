#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <values.h>
#define N 30

int id, *trazim, *broj, p, r, stolovi[N]={0};
void KO_ulaz (int i, int x);
void KO_izlaz (int i);

void izvrsi (int i, int j){
	sleep (1);
	int x=0, y,n=0,a;
	while (n!=j){   x++;
			if (x>i)
				x=1;
			y=rand()%j+1;
			printf ("\nProces %d: odabirem stol %d", x, y);
			if(stolovi[y]==0){
				KO_ulaz(N,y);
				printf("\nProces %d: rezerviram stol %d",x ,y);
				stolovi[y]=x;
				n++;
			}
			else
			printf("\nProces %d: neuspjela rezervacija stola %d",x ,y);
			printf ("\nstanje: ");
			for (a=1;a<=j;a++){
				if(stolovi[a]==0)
					printf ("-");
				else
					printf ("%d", stolovi[a]);
			}
			printf ("\n");

	}
}

void KO_ulaz (int i, int x) {
	int max,j;
	trazim [i]=1;
	max=broj[0];
	for(j=1; j<r; j++)
		if(max<broj[j])
			max=broj[j];
	broj[i]=max+1;
	trazim[i]=0;
	for (j=0;j<p-1;j++){
		while (trazim[j]!=0);
		while (broj[j] != 0 && (broj[j] < broj[i] || (broj[j] == broj[i] && j < i)));
}
}

void KO_izlaz(int i) {
	broj[i]=0;
}

void brisi(int sig){
   /* oslobađanje zajedničke memorije */
   (void) shmdt((char *) stolovi);
   (void) shmctl(id, IPC_RMID, NULL);
   exit(0);
}

int main (int argc, char *argv[]) {
	int a=0;
	srand ((unsigned)time(NULL));
	id=shmget(IPC_PRIVATE, sizeof(int)*100, 0600);
	if (id==-1)
		exit (1);
	trazim=(int *)shmat(id, NULL, 0);
	broj=(int *)shmat(id, NULL, 0)+(N+1)*sizeof(int);
	p=atoi(argv[1]);
	r=atoi(argv[2]);
	sigset(SIGINT, brisi);
	switch (fork()){
			case 0:
				izvrsi (p, r);
				break;
			case -1:
				printf ("Nije moguće stvoriti proces!");
				break;
	}
	for (a;a<r;a++)
		wait (NULL);
	brisi (0);
	return 0;
}
