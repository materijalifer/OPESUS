#include <stdio.h>
#include <signal.h>

#define N 6    /* broj razina prekida */

int OZNAKA_CEKANJA[N];
int PRIORITET[N];
int TEKUCI_PRIORITET;
void prekidna_rutina(int sig);

int sig[]={SIGUSR1, SIGUSR2, SIGILL, SIGPIPE, SIGINT};
void zabrani_prekidanje(){
   int i;
   for(i=0; i<5; i++)
      sighold(sig[i]);
}
void dozvoli_prekidanje(){
   int i;
   for(i=0; i<5; i++)
      sigrelse(sig[i]);
}

void obrada_prekida(int i){
        sigset (SIGUSR1, prekidna_rutina);
        sigset (SIGUSR2, prekidna_rutina);
        sigset (SIGILL, prekidna_rutina);
        sigset (SIGPIPE, prekidna_rutina);
        sigset (SIGINT, prekidna_rutina);
    int x=0;
        switch (i){
                case (1):
                        printf ("- P - - - -\n");
                        for (x=1;x<=5;x++){
                                printf ("- %d - - - -\n",x);
                                sleep (1);
                        }
                        printf ("- K - - - -\n");
                        break;
						
                case (2):
                        printf ("- - P - - -\n");
                        for (x=1;x<=5;x++){
                                printf ("- - %d - - -\n",x);
                                sleep (1);
                        }
                        printf ("- - K - - -\n");
                        break;

                case (3):
                        printf ("- - - P - -\n");
                        for (x=1;x<=5;x++){
                                printf ("- - - %d - -\n",x);
                                sleep (1);
                        }
                        printf ("- - - K - -\n");
                        break;

                case (4):
                        printf ("- - - - P -\n");
                        for (x=1;x<=5;x++){
                                printf ("- - - - %d -\n",x);
                                sleep (1);
                        }
                        printf ("- - - - K -\n");
                        break;

                case (5):
                        printf ("- - - - - P\n");
                        for (x=1;x<=5;x++){
                                printf ("- - - - - %d\n",x);
                                sleep (1);
                        }
                        printf ("- - - - - K\n");
                        break;
        }
}
void prekidna_rutina(int sig){
   int n=1,i,x;
   zabrani_prekidanje();
   switch(sig){
      case SIGUSR1:
         n=1;
         printf("- X - - - -\n");
         break;
      case SIGUSR2:
         n=2;
         printf("- - X - - -\n");
         break;
      case SIGILL:
         n=3;
         printf("- - - X - -\n");
         break;
          case SIGPIPE:
         n=4;
         printf("- - - - X -\n");
         break;
      case SIGINT:
         n=5;
         printf("- - - - - X\n");
         break;
   }
   OZNAKA_CEKANJA[n]=1;
   if (TEKUCI_PRIORITET<n){
   do {
   x=0;
                for (i=TEKUCI_PRIORITET+1;i<N;i++)
                        if (OZNAKA_CEKANJA[i]==1)
                                x=i;
                if (x>0){
                        OZNAKA_CEKANJA[x]=0;
                        PRIORITET[x]=TEKUCI_PRIORITET;
                        TEKUCI_PRIORITET=x;
                        dozvoli_prekidanje;
						obrada_prekida(x);
                        zabrani_prekidanje;
                        TEKUCI_PRIORITET=PRIORITET[x];
                }

   }while (x>0);
   }
   dozvoli_prekidanje();
}

int main ( void )
{
   sigset (SIGUSR1, prekidna_rutina);
   sigset (SIGUSR2, prekidna_rutina);
   sigset (SIGILL, prekidna_rutina);
   sigset (SIGPIPE, prekidna_rutina);
   sigset (SIGINT, prekidna_rutina);
   int a;

   printf("Proces obrade prekida, PID=%d\n", getpid());
   printf("\nGP S1 S2 S3 S4 S5\n\n");
   sleep (10);
   for (a=0;a<=20;a++) {
       sleep(1);
       printf("%d - - - - -\n",a);
       }
   printf ("Zavrsio osnovni program\n");

   return 0;
}



