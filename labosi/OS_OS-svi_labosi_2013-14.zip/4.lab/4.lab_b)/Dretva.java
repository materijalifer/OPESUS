package os.lab.b;

import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.Semaphore;

import os.lab.b.Stranicenje.Struct;

public class Dretva extends Thread
{
	public LinkedList<Struct> zahtjevi=new LinkedList<Struct>();
	Semaphore semafor1=new Semaphore(1);
	Semaphore semafor2=new Semaphore(1);
	public int br_zahtjeva;
	public Random random=new Random();
	
	public Dretva(LinkedList<Struct> list, int br_zahtjeva, Semaphore sem1, Semaphore sem2) 
	{
		zahtjevi=list;
		this.br_zahtjeva=br_zahtjeva;
		semafor1=sem1;
		semafor2=sem2;
	}
	
	@Override
	public void run() 
	{ 
		try {
			semafor2.acquire();
		} catch (InterruptedException e1) {
			System.err.println(e1);
		}
		
		for (int i = 0; i < br_zahtjeva; i++) 
		{
			Struct pom=new Struct();
			pom.broj=random.nextInt(9);
			zahtjevi.add(pom);
			System.out.print(pom.broj + ",");
		}
		System.out.print("    ");
		
		semafor1.release();
		
		for (int i = 0; i < br_zahtjeva; i++) 
		{	 
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				System.err.println(e);
			}
			
			try {
				semafor2.acquire();
			} catch (InterruptedException e1) {
				System.err.println(e1);
			}
			
			zahtjevi.add(new Struct(random.nextInt(9), -1));
			for (Struct pom : zahtjevi) System.out.print(pom.broj + ",");
			System.out.print("    ");
				
			semafor1.release();
		}
		
		for(int i=1;!zahtjevi.isEmpty();i++) 
		{
			try {
				semafor2.acquire();
			} catch (InterruptedException e) {
				System.err.println(e);
			}
			
			for (Struct pom : zahtjevi) System.out.print(pom.broj+",");
			for (int j = 0; j < i; j++) System.out.print("  ");
			System.out.print("    ");
			
			semafor1.release();
		}
	}
}
