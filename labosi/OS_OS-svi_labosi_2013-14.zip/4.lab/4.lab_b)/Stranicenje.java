package os.lab.b;

import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.concurrent.Semaphore;

public class Stranicenje 
{
	public static double zadnji_broj=0;
	public static LinkedList<Struct> zahtjevi=new LinkedList<Struct>();
	public static LinkedList<Struct> ram=new LinkedList<Struct>();

	public static void main(String[] args) 
	{	
		int velicina_ram=Integer.parseInt(args[0]);
		int br_zahtjeva=Integer.parseInt(args[1]);
		
		if(velicina_ram<4 || velicina_ram>10 || br_zahtjeva<5 || br_zahtjeva>20) 
		{
			System.out.println("Pocetni parametri nisu unutar dozvoljenih granica!");
			return;
		}
		
		Semaphore semafor1=new Semaphore(1);
		Semaphore semafor2=new Semaphore(1);
		Dretva dretva=new Dretva(zahtjevi, br_zahtjeva, semafor1, semafor2);
		for (int i = 0; i < velicina_ram; i++) ram.add(new Struct(-1, -1));
		
		try {
			semafor1.acquire();
		} catch (InterruptedException e2) {
			System.err.println(e2);
		}
		
		System.out.print("Zahtjevi     #N     ");
		for (int i = 1; i <= velicina_ram; i++) System.out.print(i+"     ");
		System.out.println("");
		for (int i = 0; i < velicina_ram; i++) System.out.print("----------");
		System.out.println("");
		
		boolean kraj=false;
		dretva.start();
		
		while(!kraj)
		{ 
			Struct pom=new Struct();
			boolean empty=false;
			boolean dodan=false;
			
			try {
				semafor1.acquire();
			} catch (InterruptedException e2) {
				System.err.println(e2);
			}
			
			try {
				pom = zahtjevi.remove();
			} catch (NoSuchElementException e) {
				empty=true;
			}
				
			if(!empty)
			{
				for (Struct struct : ram) 
				{
					if(struct.broj==pom.broj) break;
					if(struct.broj==-1)
					{
						pom.lru=++zadnji_broj;
						ram.add(ram.indexOf(struct), pom);
						ram.remove(struct);
						printRAM(velicina_ram, false, ram.indexOf(pom));
						dodan=true;
						break;
					}
				}
					
				if(!dodan) 
				{
					for (Struct struct : ram) 
					{
						if(struct.broj==pom.broj) 
						{
							struct.lru=++zadnji_broj;
							printRAM(velicina_ram, true, ram.indexOf(struct));
							dodan=true;
						}
					}
							
					if(!dodan)
					{
						Struct struct=ram.element();
						double min=struct.lru;
						int index=ram.indexOf(struct);
						
						for (int i = 1; i < ram.size(); i++) 
						{
							struct=ram.get(i);
							if(struct.lru<min) 
							{
								min=struct.lru;
								index=i;
							}
						}
					
						if(index==-1) kraj=true;
						else
						{	
							pom.lru=++zadnji_broj;
							ram.add(index, pom);
							ram.remove(index+1);
							printRAM(velicina_ram, false, index);
						}
					}	
				}					
			}
				
			else kraj=true;
			
			semafor2.release();
		}
			
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			System.err.println(e);
		}
	}
	
	public static void printRAM(int velicina_ram, boolean postoji, int index)
	{
		String s, s2;
		Struct pom=new Struct();
		boolean sljedeci=false;
		
		if(postoji)
		{
			s="(";
			s2=")";
		}
		else
		{
			s="[";
			s2="]";
		}
		
		try {
			pom=ram.get(index);
		} catch (Exception e) {
			System.out.println(e);
			return;
		}
		System.out.print(pom.broj);
		
		for (Struct struct : ram) 
		{
			if(struct.broj==-1) System.out.print("     -");
			else
			{
				if(ram.indexOf(struct)==index) 
				{
					System.out.print("    "+s+struct.broj+s2);
					sljedeci=true;
				}
				else 
				{
					if(sljedeci) {System.out.print("    ");sljedeci=false;}
					else System.out.print("     ");
					System.out.print(struct.broj);
				}
			}
		}
		
		if(postoji) System.out.print("  #pogodak");
		System.out.println("");
	}
	
	public static class Struct 
	{
		public int broj;
		public double lru;
		
		public Struct()
		{
			broj=0;
			lru=-1;
		}
		
		public Struct(int broj, double lru)
		{
			this.broj=broj;
			this.lru=lru;
		}
	}
}
