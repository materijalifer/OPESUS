package os.lab;

public class Zaglavlje 
{
	public int velicina_bloka;
	public int pocetak;
	
	public int sljedeci_blok;
	public boolean slobodan;
	
	public char oznaka;
	
	public Zaglavlje()
	{
		velicina_bloka=0;
		pocetak=-1;
		sljedeci_blok=-1;
		slobodan=false;
		oznaka='z';
	}
	
	public Zaglavlje(int duljina, int pocetak, int sljedeci, boolean slobodan)
	{
		velicina_bloka=duljina;
		this.pocetak=pocetak;
		sljedeci_blok=sljedeci;
		this.slobodan=slobodan;
		
		if (slobodan) oznaka='s';
		else oznaka='z';
	}
}
