package os.lab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.ListIterator;

public class Main 
{
	public static BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
	public static ArrayList<Zaglavlje> lista_slobodnih=new ArrayList<Zaglavlje>();
	public static ArrayList<Zaglavlje> lista_blokova=new ArrayList<Zaglavlje>();
	
	public static void main(String[] args) 
	{	
		System.out.print("Unesite velicinu spremnika: ");
		String s="";
		try {
			s = reader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		int broj_blokova=Integer.parseInt(s);
		addToList(new Zaglavlje(broj_blokova, 0, -1, true), "slobodni");
		addToList(new Zaglavlje(broj_blokova, 0, -1, true), "blokovi");
		
		while (true) 
		{
			printStanje();
			
			System.out.print("Unesi zahtjev (d-dodijeli, o-oslobodi, p-prekid izvodenja): ");
			try {
				s=reader.readLine();
			} catch (IOException e) {
				System.out.println("Uneseni parametar nije valjan!");
			}
			
			switch(s)
			{
				case "d":
					dodijeli();
					break;
				
				case "o":
					oslobodi();
					break;
				
				case "p":
					break;
					
				default:
					System.out.println("Doslo je do pogreske!!");
					return;
			}
			
			if(s.equals("p")) break;
		}
		
		System.out.println("Izvodenje programa zavrseno!");
	}
	
	public static void printStanje()
	{
		System.out.println("");
		System.out.println("RS: broj blokova = " + lista_blokova.size() + ", slobodni = " + lista_slobodnih.size() + ", zauzeti = " + (lista_blokova.size()-lista_slobodnih.size()));
		
		for (Zaglavlje zaglavlje : lista_blokova) 
		{
			System.out.println((lista_blokova.indexOf(zaglavlje)+1) + ": pocetak = " + zaglavlje.pocetak + ", velicina = " + zaglavlje.velicina_bloka + ", oznaka = " + zaglavlje.oznaka);
		}
		System.out.println("");
	}
	
	public static int dodijeli()
	{
		System.out.print("Unesi velicinu programa (u oktetima): ");
		String s="";
		try {
			s = reader.readLine();
		} catch (IOException e) {
			System.out.println("Uneseni parametar nije valjan!");
			return -1;
		}
		int velicina=Integer.parseInt(s);
		Zaglavlje zaglavlje, zaglavlje2=new Zaglavlje();
		Zaglavlje pom=new Zaglavlje();
		int index=-1;
		
		for (int i = 0; i < lista_slobodnih.size(); i++) 
		{
			zaglavlje=lista_slobodnih.get(i);
			
			if(lista_slobodnih.size()==1 && zaglavlje.velicina_bloka>=velicina+3)
			{
				index=0;
				break;
			}
			
			if(zaglavlje.velicina_bloka<velicina+3) 
			{
				index=i-1;
				break;
			}
			
			if(i==lista_slobodnih.size()-1) index=i;
		}
		
		if(index==-1)
		{
			System.out.println("Ne postoji slobodan blok dovoljno velik da se pospremi program od " + s + " okteta");
			return -1;
		}
		
		zaglavlje=lista_slobodnih.get(index);
		lista_slobodnih.remove(index);
		
		for (int i=0;i<lista_blokova.size();i++) 
		{
			zaglavlje2=lista_blokova.get(i);
			if(zaglavlje2.pocetak==zaglavlje.pocetak) lista_blokova.remove(i);
		}
		
		if((zaglavlje.velicina_bloka-(velicina+3))<4)
		{
			zaglavlje.sljedeci_blok=-1;
			zaglavlje.slobodan=false;
			zaglavlje.oznaka='z';
			addToList(zaglavlje, "blokovi");
		}
		
		else
		{
			int ostatak=zaglavlje.velicina_bloka-(velicina+3);
			int sljedeci_blok=zaglavlje.sljedeci_blok;
			index=zaglavlje.pocetak;
			
			zaglavlje.velicina_bloka=velicina+3;
			zaglavlje.slobodan=false;
			zaglavlje.oznaka='z';
			zaglavlje.sljedeci_blok=-1;
			
			addToList(zaglavlje, "blokovi");
			
			pom.velicina_bloka=ostatak;
			pom.pocetak=index+velicina+3;
			pom.slobodan=true;
			pom.oznaka='s';
			pom.sljedeci_blok=sljedeci_blok;
			
			addToList(pom, "slobodni");
			addToList(pom, "blokovi");
		}
		
		return index+3;
	}
	
	public static void oslobodi()
	{
		System.out.print("Unesi pocetnu adresu programa: ");
		String s="";
		try {
			s = reader.readLine();
		} catch (IOException e) {
			System.out.println("Uneseni parametar nije valjan!");
		}
		int pocetak_bloka=Integer.parseInt(s);
		Zaglavlje pom1, pom3;
		Zaglavlje pom2=new Zaglavlje();
		
		for (Zaglavlje zaglavlje : lista_blokova) 
		{
			if(zaglavlje.pocetak==pocetak_bloka)
			{
				pom2=zaglavlje;
				break;
			}
		}
		
		int index=lista_blokova.indexOf(pom2);
		System.out.println("pocetna adresa: "+pom2.pocetak+", velicina: "+pom2.velicina_bloka);
		if(index==-1)
		{
			System.out.println("U memoriji ne postoji blok s ovom pocetnom adresom!");
			return;
		}
		
		try {
			pom1=lista_blokova.get(index-1);
		} catch (IndexOutOfBoundsException e) {
			pom1=new Zaglavlje();
		}
		
		try {
			pom3=lista_blokova.get(index+1);
		} catch (IndexOutOfBoundsException e) {
			pom3=new Zaglavlje();
		}
		
		if(pom1.oznaka=='s' && pom3.oznaka=='s')
		{
			lista_blokova.remove(index-1);
			lista_blokova.remove(index-1);
			lista_blokova.remove(index-1);
			
			lista_slobodnih.remove(pom1);
			lista_slobodnih.remove(pom3);
			
			pom1.velicina_bloka+=pom2.velicina_bloka+pom3.velicina_bloka;
			pom1.sljedeci_blok=pom3.sljedeci_blok;
			lista_blokova.add(index-1, pom1);
			addToList(pom1, "slobodni");
		}
		
		else
		{
			if(pom1.oznaka=='s')
			{
				lista_blokova.remove(index-1);
				lista_blokova.remove(index-1);
				
				lista_slobodnih.remove(pom1);
				
				pom1.velicina_bloka+=pom2.velicina_bloka;
				lista_blokova.add(index-1, pom1);
				addToList(pom1, "slobodni");
			}
			
			else 
			{
				if(pom3.oznaka=='s')
				{	
					lista_blokova.remove(index);
					lista_blokova.remove(index);
					
					lista_slobodnih.remove(pom3);
				
					pom3.velicina_bloka+=pom2.velicina_bloka;
					pom3.pocetak=pom2.pocetak;
					lista_blokova.add(index, pom3);
					addToList(pom3, "slobodni");
				}
				
				else 
				{
					lista_blokova.remove(index);
					
					pom2.slobodan=true;
					pom2.oznaka='s';
					addToList(pom2, "slobodni");
					addToList(pom2, "blokovi");
				}
			}
		}
	}
	
	public static void addToList(Zaglavlje zaglavlje, String s)
	{
		Zaglavlje pom;
		ListIterator<Zaglavlje> iterator;
		
		if(s.equals("blokovi"))
		{
			iterator=lista_blokova.listIterator();
			
			while (iterator.hasNext()) 
			{	
				pom=iterator.next();
				if(pom.pocetak>zaglavlje.pocetak)
				{
					iterator.previous();
					iterator.add(zaglavlje);
					break;
				}
				
				if(!iterator.hasNext()) iterator.add(zaglavlje);
			}
			
			if(lista_blokova.isEmpty()) lista_blokova.add(zaglavlje);
		}
		
		else 
		{
			iterator=lista_slobodnih.listIterator();
			
			if(s.equals("slobodni"))
			{
				while (iterator.hasNext()) 
				{	
					pom=iterator.next();
					
					if(pom.velicina_bloka<zaglavlje.velicina_bloka)
					{
						iterator.previous();
						iterator.add(zaglavlje);
						break;
					}
					
					if(!iterator.hasNext()) iterator.add(zaglavlje);
				}
				
				if(lista_slobodnih.isEmpty()) lista_slobodnih.add(zaglavlje);
			}
			
			else System.out.println("Neuspjelo dodadavnje u listu, drugi argument metode nije valjan.");
		}
	}
}
