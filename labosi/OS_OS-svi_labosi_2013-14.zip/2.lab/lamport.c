#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <values.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>

int zadnji_broj=0, *broj, *ulaz, *stolovi, segid;

void rezervacija(int i, int n, int s);
void kriticni_odsjecak(int i, int *niz, int stol, int s);
void izbrisi();

void main(int argc, char *argv[]) {

	int n=atoi(argv[1]);
	int s=atoi(argv [2]);
	int i;

	srand((unsigned)time(NULL));
	sigset(SIGINT, izbrisi);

	segid=shmget(IPC_PRIVATE, 2*sizeof(int)*(n+1)+sizeof(int)*(s+1), 0600);
	broj=(int *)shmat(segid, NULL, 0);
	ulaz=(int *)shmat(segid, NULL, 0)+n+1;
	stolovi=(int *)shmat(segid, NULL, 0)+2*n+2;

	for(i=1;i<=n;i++) {
	
		if(fork()==0) {
			rezervacija(i, n, s);
			exit(0);
		}
	}

	while(--i) wait(NULL);
	izbrisi();
}

void rezervacija(int i, int n, int s) {

	int j, *niz=NULL, brojac=0, stol;

	while(1) 
	{
		*(ulaz+i)=1;

		*(broj+i)=zadnji_broj+1;
		zadnji_broj=*(broj+i);
		*(ulaz+i)=0;
		sleep(1);

		for(j=1;j<=s;j++) 
		{
			if(*(stolovi+j)==0) 
			{
				brojac++;
				niz=realloc(niz, sizeof(int)*(brojac+1));
				*(niz+brojac)=j;
			}
		}

		if(brojac==0) break;
		if(brojac>1) stol=rand() % brojac+1;
		else stol=1;
		printf("Proces %d: Odabirem stol %d\n", i, *(niz+stol));

		for(j=1;j<=n;j++)
		{
			while(*(ulaz+j));
			while((*(broj+j)) && (*(broj+j)<*(broj+i)) && (j<i));
		}

		kriticni_odsjecak(i, niz, stol, s);

		*(broj+i)=0;
		free(niz);
		niz=NULL;
		brojac=0;
	}
}
			

void kriticni_odsjecak(int i, int *niz, int stol, int s) {

	int j;	
	
	if( *(stolovi+*(niz+stol)) ) 
		{
			printf("Proces %d, Neuspjela rezervacija stola %d, stanje: ", i, *(niz+stol));
			for(j=1;j<=s;j++) {
	
				if(*(stolovi+j)) printf("%d ", *(stolovi+j));
				else printf("- ");
			}
		}
		else 
		{
			printf("Proces %d, Rezerviram stol %d, stanje: ", i, *(niz+stol));
			*(stolovi+*(niz+stol))=i;
			for(j=1;j<=s;j++) {
	
				if(*(stolovi+j)) printf("%d ", *(stolovi+j));
				else printf("- ");
			}
		}

		printf("\n");
		usleep(10);
}
	
void izbrisi() {

	shmdt(ulaz);
	shmdt(broj);
	shmdt(stolovi);
	shmctl(segid, IPC_RMID, NULL);
	exit(0);
}
