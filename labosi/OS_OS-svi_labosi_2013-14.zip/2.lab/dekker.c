#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <signal.h>

int zastavica[3]={0};
int pravo=1;

void *funkcija(void *br);
void prekini();

void main() {

	int i=1, j=2;
	pthread_t thread1, thread2;

	sigset(SIGINT, prekini);

	pthread_create(&thread1, NULL, (void *) &funkcija, (void *) &i);
	pthread_create(&thread2, NULL, (void *) &funkcija, (void *) &j);

	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);

	exit(0);
}

void *funkcija(void *br) {

	int i=*((int *)br), j, k, h;
	
	if(i==1) j=2;
	else j=1;
	
	for(k=1;k<=5;k++) 
	{
		zastavica[i]=1;
		
		while(zastavica[j]) 
		{
			if(pravo!=i) {

				zastavica[i]=0;
				while(pravo!=i);
				zastavica[i]=1;
			}
		}

		for(h=1;h<=5;h++) 
		{		
			printf("Dretva: %d, K.O. br: %d (%d/5)\n", i, k, h);
			usleep(1);
		}
	
		pravo=j;
		usleep(10);
		zastavica[i]=0;
	}
}

void prekini() {exit(1);}			
		

	
