#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#define MAXL 10000

int ulaz_f=1, izbroji=0, suma_f=0, kraj=0, rijeci=0, zastitna_suma=0;
char MS[MAXL]={'\0'};

void obrada_txt(char *dat);
void ulaz(void *dat);
void izbroji_rijeci();
void suma();

void main(int argc, char *argv[]) {

	int i, j=0, k=0, br=0;	
	char *niz=NULL;
	
	for(i=0;i<argc-1;i++) 
	{
		niz=strchr(argv[i+1], '.');
		if(!niz) {
			printf("Krivo unesena datoteka %s!", argv[i+1]);
			continue;
		}

		j=strcmp(niz, ".txt");
		k=strcmp(niz, ".html");
		
		if(!j) 
		{
			br++;	
			if(fork()==0) {
				obrada_txt(argv[i+1]);
				exit(0);
			}
		}

		else if(!k) 
		{
			br++;
			if(fork()==0) {
				obrada_html(argv[i+1]);
				exit(0);
			}
		}
		
		else printf("kurac");
	}

	while(br--) wait(NULL);
}

void obrada_txt(char *dat) {

	FILE *source;
	pthread_t thread1, thread2, thread3;

	source=fopen(dat, "r");

	pthread_create(&thread1, NULL, (void *) &ulaz, (void *)source);
	pthread_create(&thread2, NULL, (void *) &izbroji_rijeci, NULL);
	pthread_create(&thread3, NULL, (void *) &suma, NULL);

	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);
	pthread_join(thread3, NULL);

	printf("Datoteka \"%s\" ima %d rijeci; zastitna suma je: %d", dat, rijeci, zastitna_suma);
	fclose(source);
}

void ulaz(void *dat) {

	FILE *source=(FILE *)dat;
	char *niz;

	while(fgets(niz, MAXL, source))
	{
		while(izbroji || suma);
		ulaz_f=1;
		strcpy(MS, niz);
		ulaz_f=0;
	}

	kraj=1;
}

void izbroji_rijeci() {

	int i;
	char niz[MAXL]={'\0'};

	while(!kraj)
	{
		while(ulaz || suma);
		izbroji=1;

		for(i=0;MS[i]!='\0';i++)
		{
			if(MS[i]==' ') {
				if(strlen(niz)>1) rijeci++;
				strcpy(niz, "\0");
			}
			else niz[i]=MS[i];
		}
		
		izbroji=0;
	}
}

void suma() {

	int i;

	while(!kraj) 
	{
		while(ulaz || izbroji);
		suma_f=1;
		for(i=0;i<strlen(MS);i++) zastitna_suma^=MS[i];
		suma_f=0;
	}
}
