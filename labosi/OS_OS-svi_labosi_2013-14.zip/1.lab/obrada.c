#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

int OZNAKA_CEKANJA[6]={0};
int PRIORITET[6]={0};
int TEK_PRIORITET=0;

int sig[6]={0, SIGABRT, SIGCONT, SIGCHLD, SIGILL, SIGINT};

void prekidna_rutina(int sig);
void obrada_prekida(int sig);
void dozvoli_prekidanje();
void zabrani_prekidanje();

void main() {
	
	int i;

	sigset(sig[1], prekidna_rutina);
	sigset(sig[2], prekidna_rutina);
	sigset(sig[3], prekidna_rutina);
	sigset(sig[4], prekidna_rutina);
	sigset(sig[5], prekidna_rutina);

	printf("Proces obrade prekida, PID=%d\n", getpid());
	printf("GP S1 S2 S3 S4 S5\n- - - - - - - - -\n\n");

	for(i=1;i<=20;i++) {
		sleep(1);
		printf(" %d  -  -  -  -  -\n", i);
	}

	printf("Zavrsio osnovni program\n");
}

void prekidna_rutina(int sig) {

	int i, x, n=0;

	zabrani_prekidanje();


	switch(sig) {

	case SIGINT:
		n=5;
		printf(" -  -  -  -  -  X\n");
		break;
	case SIGILL:
		n=4;
		printf(" -  -  -  -  X  -\n");
		break;
	case SIGCHLD:
		n=3;
		printf(" -  -  -  X  -  -\n");
		break;
	case SIGCONT:
		n=2;
		printf(" -  -  X  -  -  -\n");
		break;
	case SIGABRT:
		n=1;
		printf(" -  X  -  -  -  -\n");
		break;
	default:
		printf("GREŠKA!!");
		exit(1);
	}
	
	OZNAKA_CEKANJA[n]++;

	do {	
		x=0;
		for(i=TEK_PRIORITET+1;i<=5;i++) if(OZNAKA_CEKANJA[i]) x=i;
	
		if(x) {
		
			OZNAKA_CEKANJA[x]--;
			PRIORITET[x]=TEK_PRIORITET;
			TEK_PRIORITET=x;
	
			dozvoli_prekidanje();
			obrada_prekida(x);
			zabrani_prekidanje();
	
			TEK_PRIORITET=PRIORITET[x];
			PRIORITET[x]=0;
		}

	} while(x);
}

void obrada_prekida(int sig) {

	int i;
		
	switch(sig) {

	case 5:
		printf(" -  -  -  -  -  P\n");
		for(i=1;i<=5;i++) {
			sleep(1);
			printf(" -  -  -  -  -  %d\n", i);
		}
		printf(" -  -  -  -  -  K\n");
		break;
	case 4:
		printf(" -  -  -  -  P  -\n");
		for(i=1;i<=5;i++) { 
			sleep(1);
			printf(" -  -  -  -  %d  -\n", i);
		}
		printf(" -  -  -  -  K  -\n");
		break;
	case 3:
		printf(" -  -  -  P  -  -\n");
		for(i=1;i<=5;i++) {
			sleep(1);	
			printf(" -  -  -  %d  -  -\n", i);
		}
		printf(" -  -  -  K  -  -\n");
		break;
	case 2:
		printf(" -  -  P  -  -  -\n");
		for(i=1;i<=5;i++) {
			sleep(1);
			printf(" -  -  %d  -  -  -\n", i);
		}
		printf(" -  -  K  -  -  -\n");
		break;
	case 1:
		printf(" -  P  -  -  -  -\n");
		for(i=1;i<=5;i++) {
			sleep(1);			
			printf(" -  %d  -  -  -  -\n", i);
		}
		printf(" -  K  -  -  -  -\n");
		break;
	default:
		printf("GREŠKA!!");
		exit(1);
	}
}

void dozvoli_prekidanje() {

	int i;

	for(i=1;i<=5;i++) {
	sigrelse(sig[i]);
	}
}

void zabrani_prekidanje() {

	int i;

	for(i=1;i<=5;i++) {
	sighold(sig[i]);
	}
}
