#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

#define brod 0
#define kanibali_lijevo 1
#define kanibali_desno 2
#define misionari_lijevo 3
#define misionari_desno 4
#define ukrcaj 5
#define lijevo 0
#define desno 1

typedef struct {
	char niz[10];
} string;

int br_kanibala[2]={0};
int br_misionara[2]={0};
int br_putnika=0;
int br_misionara_brod=0;
int br_kanibala_brod=0;
int br_voznji=0;
int prevezeno_misionara=0;
int prevezeno_kanibala=0;
int obala=desno;
string strane[2];
pthread_mutex_t monitor;
pthread_cond_t red_uvjeta[6];

void camac();
void generator();
void kanibal();
void misionar();
void zavrsi();
void ukrcavanje_prevozenje(int n);
void print();

void main()
{
	pthread_t thread_brod, thread_generator;

	sigset(SIGINT, zavrsi);

	strcpy(strane[lijevo].niz, "LIJEVOJ");
	strcpy(strane[desno].niz, "DESNOJ");

	pthread_mutex_init(&monitor, NULL);
	pthread_cond_init(red_uvjeta, NULL);

	pthread_create(&thread_brod, NULL, (void *) &camac, NULL);
	pthread_create(&thread_generator, NULL, (void *) &generator, NULL);

	while(1);
}

void camac()
{
	pthread_mutex_lock(&monitor);

	while(1)
	{
		obala=desno;
		printf("\n\t## BROD JE NA DESNOJ OBALI RIJEKE ##\n\n");
		sleep(1);
		print();
		pthread_cond_broadcast(&red_uvjeta[misionari_desno]);
		pthread_cond_broadcast(&red_uvjeta[kanibali_desno]);

		if(br_putnika<3) pthread_cond_wait(&red_uvjeta[brod], &monitor);

		printf("\n# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #\n");
		printf("\n\tUKRCAVAM %d MISIONARA I %d KANIBALA", br_misionara_brod, br_kanibala_brod);
		ukrcavanje_prevozenje(1);//ukrcavanje

		printf("\n\tPREVOZIM PUTNIKE PREKO RIJEKE");
		ukrcavanje_prevozenje(2);//prevozenje
		br_voznji++;
		printf("\n\n# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #\n");

		pthread_cond_broadcast(&red_uvjeta[ukrcaj]);

		br_putnika=0;
		br_misionara[desno]-=br_misionara_brod;
		br_kanibala[desno]-=br_kanibala_brod;
		prevezeno_misionara+=br_misionara_brod;
		prevezeno_kanibala+=br_kanibala_brod;
		br_misionara_brod=0;
		br_kanibala_brod=0;
		
		obala=lijevo;
		printf("\n\t## BROD JE NA LIJEVOJ OBALI RIJEKE ##\n\n");
		sleep(1);
		print();
		pthread_cond_broadcast(&red_uvjeta[misionari_lijevo]);
		pthread_cond_broadcast(&red_uvjeta[kanibali_lijevo]);

		if(br_putnika<3) pthread_cond_wait(&red_uvjeta[brod], &monitor);

		printf("\n# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #\n");
		printf("\n\tUKRCAVAM %d MISIONARA I %d KANIBALA", br_misionara_brod, br_kanibala_brod);
		ukrcavanje_prevozenje(1);//ukrcavanje

		printf("\n\tPREVOZIM PUTNIKE PREKO RIJEKE");
		ukrcavanje_prevozenje(2);//prevozenje
		br_voznji++;
		printf("\n\n# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #\n");

		pthread_cond_broadcast(&red_uvjeta[ukrcaj]);

		br_putnika=0;
		br_misionara[lijevo]-=br_misionara_brod;
		br_kanibala[lijevo]-=br_kanibala_brod;
		prevezeno_misionara+=br_misionara_brod;
		prevezeno_kanibala+=br_kanibala_brod;
		br_misionara_brod=0;
		br_kanibala_brod=0;

	}
}

void generator()
{
	pthread_t thread_misionar, thread_kanibal;

	while(1)
	{
		sleep(2);
		pthread_create(&thread_kanibal, NULL, (void *) &kanibal, NULL);
		sleep(2);
		pthread_create(&thread_kanibal, NULL, (void *) &kanibal, NULL);
		pthread_create(&thread_misionar, NULL, (void *) &misionar, NULL);
	}
}

void misionar()
{
	int misionar_obala, ukrcan=0;
	int red_br_misionara[2];
	srand((unsigned)time(NULL));

	misionar_obala=rand()%(desno-lijevo+1)+lijevo;
	pthread_mutex_lock(&monitor);

	if(misionar_obala==lijevo) 
	{
		br_misionara[lijevo]++;
		red_br_misionara[lijevo]=br_misionara[lijevo];
	}

	else 
	{
		br_misionara[desno]++;
		red_br_misionara[desno]=br_misionara[desno];
	}

	while(!ukrcan)
	{	
		if(obala==misionar_obala)
		{
			if(br_putnika<7)
			{
				br_misionara_brod++;
				br_putnika++;
				ukrcan=1;

				printf("%d.MISIONAR ceka ukrcavanje\n", red_br_misionara[misionar_obala]);
				printf("Ukrcavanje na %s obali ceka: %d MISIONARA i %d KANIBALA\n", strane[misionar_obala].niz, br_misionara_brod, br_kanibala_brod);
				
				if(br_putnika>=3 && br_putnika<=7 && br_misionara_brod>br_kanibala_brod) pthread_cond_signal(&red_uvjeta[brod]);
				
				print();
				pthread_cond_wait(&red_uvjeta[ukrcaj], &monitor);
			}

			else 
			{	 
			 	printf("Za %d.MISIONARA nema mjesta u brodu pa ce pricekati drugu priliku\n", red_br_misionara[misionar_obala]);
			 	printf("Ukrcavanje za sljedecu turu na %s obali ceka: %d MISIONARA i %d KANIBALA\n", strane[misionar_obala].niz, br_misionara[misionar_obala]-br_misionara_brod, br_kanibala[misionar_obala]-br_kanibala_brod);
			 	print();
			 	pthread_cond_wait(&red_uvjeta[misionari_desno], &monitor);
			}
		}

		else
		{	
			if(misionar_obala==lijevo)
			{
				printf("%d.MISIONAR na LIJEVOJ OBALI nije zatekao brod pa ce ga pricekati\n", red_br_misionara[lijevo]);
				printf("Ukrcavanje za sljedecu turu na LIJEVOJ OBALI ceka: %d MISIONARA i %d KANIBALA\n", br_misionara[lijevo], br_kanibala[lijevo]);
				print();
				pthread_cond_wait(&red_uvjeta[misionari_lijevo], &monitor);
			}

			else
			{
				printf("%d.MISIONAR na DESNOJ OBALI nije zatekao brod pa ce ga pricekati\n", red_br_misionara[desno]);
				printf("Ukrcavanje za sljedecu turu na DESNOJ OBALI ceka: %d MISIONARA i %d KANIBALA\n", br_misionara[desno], br_kanibala[desno]);
				print();
				pthread_cond_wait(&red_uvjeta[misionari_desno], &monitor);
			}
		}
			
	}	

	pthread_mutex_unlock(&monitor);
}

void kanibal()
{
	int kanibal_obala, ukrcan=0;
	int red_br_kanibala[2];
	srand((unsigned)time(NULL));

	kanibal_obala=rand()%(desno-lijevo+1)+lijevo;
	pthread_mutex_lock(&monitor);

	if(kanibal_obala==lijevo)
	{
		br_kanibala[lijevo]++;
		red_br_kanibala[lijevo]=br_kanibala[lijevo];
	}

	else 
	{
		br_kanibala[desno]++;
		red_br_kanibala[desno]=br_kanibala[desno];
	}

	while(!ukrcan)
	{
		if(obala==kanibal_obala)
		{
			if(br_putnika<3)
			{
				br_kanibala_brod++;
				br_putnika++;
				ukrcan=1;

				printf("%d.KANIBAL ceka ukrcavanje\n", red_br_kanibala[kanibal_obala]);
				printf("Ukrcavanje na %s OBALI ceka: %d MISIONARA i %d KANIBALA\n", strane[kanibal_obala].niz, br_misionara_brod, br_kanibala_brod);
				
				if(br_putnika>=3 && br_putnika<=7 && br_misionara_brod>br_kanibala_brod) pthread_cond_signal(&red_uvjeta[brod]);
				
				print();
				pthread_cond_wait(&red_uvjeta[ukrcaj], &monitor);
			}

			else 
			{	
				if(br_putnika>=3 && br_putnika<7 && br_kanibala_brod+1<br_misionara_brod)
				{			
					br_kanibala_brod++;
					br_putnika++;
					ukrcan=1;

					printf("%d.KANIBAL ceka ukrcavanje\n", red_br_kanibala[kanibal_obala]);
					printf("Ukrcavanje na %s OBALI ceka: %d MISIONARA i %d KANIBALA\n", strane[kanibal_obala].niz, br_misionara_brod, br_kanibala_brod);
					
					if(br_putnika>=3 && br_putnika<=7 && br_misionara_brod>br_kanibala_brod) pthread_cond_signal(&red_uvjeta[brod]);
					
					print();
					pthread_cond_wait(&red_uvjeta[ukrcaj], &monitor);
				}

				else 
				{
			 		printf("Za %d.KANIBALA nema mjesta u brodu pa ce pricekati drugu priliku\n", red_br_kanibala[kanibal_obala]);
			 		printf("Ukrcavanje za sljedecu turu na %s OBALI ceka: %d MISIONARA i %d KANIBALA\n", strane[kanibal_obala].niz, br_misionara[kanibal_obala]-br_misionara_brod, br_kanibala[kanibal_obala]-br_kanibala_brod);
			 		print();
			 		pthread_cond_wait(&red_uvjeta[kanibali_desno], &monitor);
				}
			}
		}

		else 
		{
			if(kanibal_obala==lijevo)
			{
	 			printf("%d.KANIBAL na LIJEVOJ OBALI nije zatekao brod pa ce ga pricekati\n", red_br_kanibala[lijevo]);
	 			printf("Ukrcavanje za sljedecu turu na LIJEVOJ OBALI ceka: %d MISIONARA i %d KANIBALA\n", br_misionara[lijevo], br_kanibala[lijevo]);
		 		print();
		 		pthread_cond_wait(&red_uvjeta[kanibali_lijevo], &monitor);
		 	}

		 	else
		 	{
		 		printf("%d.KANIBAL na DESNOJ OBALI nije zatekao brod pa ce ga pricekati\n", red_br_kanibala[desno]);
		 		printf("Ukrcavanje za sljedecu turu na DESNOJ OBALI ceka: %d MISIONARA i %d KANIBALA\n", br_misionara[desno], br_kanibala[desno]);
		 		print();
		 		pthread_cond_wait(&red_uvjeta[kanibali_desno], &monitor);
		 	}
		}
	}	

	pthread_mutex_unlock(&monitor);
}

void ukrcavanje_prevozenje(int n)
{
	int i;
	for(i=0;i<n*2;i++)
	{
		sleep(1);
		fflush(stdout);
		printf(" -");
	}
}

void print() {printf("-----------------------------------------------------------------------------\n");}

void zavrsi() 
{
	printf("\n\n\tPRIJEVOZ PUTNIKA ZAVRSIO!\n\n\tPREVEZENO JE %d PUTNIKA\n\tOD TOGA %d MISIONARA I %d KANIBALA\n\n\tBEZ PRIJEVOZA JE OSTALO %d PUTNIKA\n\tOD TOGA %d MISIONARA I %d KANIBALA\n\n", prevezeno_misionara+prevezeno_kanibala, prevezeno_misionara, prevezeno_kanibala, br_misionara[lijevo]+br_misionara[desno]+br_kanibala[lijevo]+br_kanibala[desno], br_misionara[lijevo]+br_misionara[desno], br_kanibala[lijevo]+br_kanibala[desno]);
	exit(0);
}