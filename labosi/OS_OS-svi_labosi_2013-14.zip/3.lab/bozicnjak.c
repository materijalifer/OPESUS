#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <signal.h>
#include <unistd.h>

#define djed 0
#define sobovi 1
#define patuljci 2

int br_sobova=0;
int br_patuljaka=0;
pthread_mutex_t monitor;
pthread_cond_t red_uvjeta[3];

void djed_mraz();
void sjeverni_pol();
void sob();
void patuljak();
void zavrsi();

void main()
{
	pthread_t thread_djed, thread_pol;

	sigset(SIGINT, zavrsi);

	pthread_mutex_init(&monitor, NULL);
	pthread_cond_init(red_uvjeta, NULL);

	pthread_create(&thread_djed, NULL, (void *) &djed_mraz, NULL);
	pthread_create(&thread_pol, NULL, (void *) &sjeverni_pol, NULL);

	while(1);
}

void djed_mraz()
{
	int i;
	pthread_mutex_lock(&monitor);

	while(1)
	{
		pthread_cond_wait(&red_uvjeta[djed], &monitor);

		printf("\nDjed se probudio i zatekao ");
		
		if(br_sobova==10 && br_patuljaka>0)
		{
			printf("10 sobova i %d patuljaka i krenuo raznositi darove\n\n", br_patuljaka);
			sleep(2);//raznosi darove
			pthread_cond_broadcast(&red_uvjeta[sobovi]);
			br_sobova=0;
		}
		
		else 
		{	
			if(br_sobova==10) 
			{
				printf("10 sobova pa ce ih nahraniti\n\n");
				sleep(2);//nahrani sobove
			}
			
			else 
			{
				if(br_patuljaka>=3)
				{
					printf("grupu od 3 patuljka ispred vrata i krenuo rjesavati njihove probleme\n\n");
					sleep(2);//rjesi patuljcima problem
					for(i=0;i<3;i++) pthread_cond_signal(&red_uvjeta[patuljci]);
					br_patuljaka-=3;
				}
			}
		}
	}
}

void sjeverni_pol()
{
	int sleep_time, sob_patuljak;
	pthread_t thread_1, thread_2;
	srand((unsigned)time(NULL));

	while(1)
	{
		sob_patuljak=rand()%2;

		if(sob_patuljak && br_sobova<10) pthread_create(&thread_1, NULL, (void *) &sob, NULL);
		else pthread_create(&thread_2, NULL, (void *) &patuljak, NULL);

		sleep_time=rand()%3+1;
		sleep(sleep_time);
	}
}

void sob()
{
	pthread_mutex_lock(&monitor);

	br_sobova++;
	if(br_sobova==10) 
	{
		printf("10. sob se vratio kod djeda i probudio ga\n");
		pthread_cond_signal(&red_uvjeta[djed]);
		pthread_cond_wait(&red_uvjeta[sobovi], &monitor);
	}
	else 
	{
		printf("%d. sob se vratio kod djeda i ceka\n", br_sobova);
		pthread_cond_wait(&red_uvjeta[sobovi], &monitor);
	}

	pthread_mutex_unlock(&monitor);
}

void patuljak()
{
	pthread_mutex_lock(&monitor);

	br_patuljaka++;
	printf("%d. patuljak je krenuo kod djeda\n", br_patuljaka);
	if(br_patuljaka>=3)
	{
		printf("Skupila se grupa od 3 patuljka i probudila djeda\n");
		pthread_cond_signal(&red_uvjeta[djed]);
	}
	
	pthread_cond_wait(&red_uvjeta[patuljci], &monitor);

	pthread_mutex_unlock(&monitor);
}

void zavrsi() {exit(0);}