#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <signal.h>
#include <unistd.h>

#define pusac_duhan 0
#define pusac_papir 1
#define pusac_sibice 2
#define trgovac_sem 3

typedef struct {
	char niz[10];
} string;

string sastojci[3];
int *stol;
int segid;
int semid;

void trgovac();
void pusac(int br_pusaca);
int SemSetVal(int SemNum, int SemVal);
int SemOp(int SemNum, int SemOp);
void brisi_zavrsi();

void main() 
{

	int i;

	strcpy(sastojci[0].niz, "duhan");
	strcpy(sastojci[1].niz, "papir");
	strcpy(sastojci[2].niz, "sibice");
	
	sigset(SIGINT, brisi_zavrsi);
	
	semid=semget(IPC_PRIVATE, 4, 0600);

	SemSetVal(pusac_duhan, 0);
	SemSetVal(pusac_papir, 0);
	SemSetVal(pusac_sibice, 0);
	SemSetVal(trgovac_sem, 1);

	segid=shmget(IPC_PRIVATE, sizeof(int)*2, 0600);
	stol=shmat(segid, NULL, 0);

	for(i=0;i<3;i++) printf("Pusac %d: ima %s\n", i+1, sastojci[i].niz);
	printf("\n\n");

	if(fork()==0) trgovac();

	for(i=0;i<3;i++) if(fork()==0) pusac(i);

	while(1);
}

void trgovac()
{
	int sastojak_1, sastojak_2, br_pusaca;
	srand((unsigned)time(NULL));

	while(1)
	{
		sastojak_1=rand()%3;

		do {
			sastojak_2=rand()%3;
		} while(sastojak_1==sastojak_2);

		do {
			br_pusaca=rand()%3;
		} while(br_pusaca==sastojak_1 || br_pusaca==sastojak_2);

		SemOp(trgovac_sem, -1);
		printf("Trgovac stavlja: %s i %s\n", sastojci[sastojak_1].niz, sastojci[sastojak_2].niz);
		stol[0]=sastojak_1;
		stol[1]=sastojak_2;

		switch(br_pusaca)
		{
			case pusac_duhan:
			SemOp(pusac_duhan, 1);
			break;

			case pusac_sibice:
			SemOp(pusac_sibice, 1);
			break;

			case pusac_papir:
			SemOp(pusac_papir, 1);
			break;

			default:
			printf("Došlo je do greške!!");
			exit(1);
		}
	}
}

void pusac(int br_pusaca)
{
	int sastojak=br_pusaca;

	while(1)
	{
		SemOp(br_pusaca, -1);

		if(stol[0]!=sastojak && stol[1]!=sastojak)
		{
			printf("Pusac %d uzima sastojke i blam blam :)\n\n", br_pusaca+1);
			SemOp(trgovac_sem, 1);
			sleep(1);//pusi
		}
		
		else 
		{
			printf("Došlo je do greške!!");
			exit(1);
		}
	}
}

int SemSetVal(int SemNum, int SemVal)
{  
   return semctl(semid, SemNum, SETVAL, SemVal);
}

int SemOp(int SemNum, int SemOp)
{  
	struct sembuf SemBuf;
	SemBuf.sem_num = SemNum;
 	SemBuf.sem_op  = SemOp;
   	SemBuf.sem_flg = 0;

   return semop(semid, &SemBuf, 1);
}

void brisi_zavrsi()
{
	shmdt(stol);
	shmctl(segid, IPC_RMID, NULL);
	semctl(semid, 0, IPC_RMID, 0);

   kill(0, SIGKILL);
}	