#include<stdio.h>
#include<sys/types.h>
#include<math.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<time.h>

int  PrazanStol=0;
int  DUHAN_PAPIR=1;
int  PAPIR_SIBICE=2;
int  DUHAN_SIBICE=3;

int SemId;

void SemGet(int n){
	SemId = semget(IPC_PRIVATE, n, 0600);
	if(SemId == -1){
		printf("Nema semafora\n");
		exit(1);
	}
}

int SemSetVal(int SemNum, int SemVal){
	return semctl(SemId, SemNum, SETVAL, &SemVal);
}

int SemOp(int SemNum, int SemOp){
	struct sembuf SemBuf;
	SemBuf.sem_num = SemNum;
	SemBuf.sem_op = SemOp;
	SemBuf.sem_flg = 0;
	return semop(SemId, &SemBuf, 1);
}

void SemRemove(void){
	(void) semctl(SemId, 0, IPC_RMID, 0);
}


void pusac1(){
	while(1){
		SemOp(DUHAN_PAPIR,-1);
		printf("Pusac 1 uzima sastojke: DUHAN, PAPIR\n");
		SemSetVal(PrazanStol,1);
	}
}

void pusac2(){
	while(1){
		SemOp(DUHAN_SIBICE, -1);
		printf("Pusac 2 uzima sastojke: DUHAN, SIBICE\n");
		SemSetVal(PrazanStol,1);
	}
}

void pusac3(){
	while(1){
		SemOp(PAPIR_SIBICE, -1);
		printf("Pusac 3 uzima sastojke: SIBICE, PAPIR.\n");
		SemSetVal(PrazanStol,1);
	}
}
			

void trgovac(){
	int sastojak1, sastojak2;
	while(1){
		SemOp(PrazanStol, -1);
		srand((unsigned)time(NULL));
		sleep(1);
		sastojak1=rand()%3+1;
		sastojak2=rand()%3+1;
		while(sastojak1==sastojak2){
			sastojak2=rand()%3;
		}


	if(sastojak1==1 && sastojak2==2){
		printf("Na stol stavljam DUHAN i SIBICE\n");
		SemOp(DUHAN_SIBICE, 1);
	}
	else if(sastojak1==1 && sastojak2==3){
		printf("Na stol stavljam DUHAN i PAPIR.\n");
		SemOp(DUHAN_PAPIR, 1);
	} else {
	     	printf("Na stol stavljam SIBICE i PAPIR.\n");
		SemOp(PAPIR_SIBICE, 1);
	}

   SemOp(PrazanStol, 1);
   }
}
	
		
		
		

int main(void){

int i;
	
	SemGet(4);
	SemOp(PrazanStol, 1);

	printf("Pusac 1 ima SIBICE.\n");
	printf("Pusac 2 ima PAPIR.\n");
	printf("Pusac 3 ima DUHAN.\n");
	printf("****************************************\n");
	
	switch(fork()){
		case -1: printf("Ne mogu stvoriti proces!\n");
		case  0: trgovac(1); exit(0);
		default: break;
	}

	switch(fork()){
                case -1: printf("Ne mogu stvoriti proces!\n");
                case  0: pusac1(); exit(0);
                default: break;
        }
	
	switch(fork()){
                case -1: printf("Ne mogu stvoriti proces!\n");
                case  0: pusac2(); exit(0);
                default: break;
        }

	switch(fork()){
                case -1: printf("Ne mogu stvoriti proces!\n");
                case  0: pusac3(); exit(0);
                default: break;
        }
	for(i=0; i<=4; i++){
		wait(NULL);
	}
	SemRemove();

return(0);
}	
