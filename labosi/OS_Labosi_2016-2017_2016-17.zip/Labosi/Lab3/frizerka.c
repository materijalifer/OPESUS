#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <math.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <time.h>
#include <semaphore.h>
#include <sys/sem.h>
static int klijenti;
static int broj_mjesta;
static int zauzeto_mjesto=0;
static int prviK;
static int radnoV = 0;
static int ZATVORENO = 0;
sem_t spavaj;
sem_t cekaonica;
sem_t gotov;
sem_t poceo;
sem_t binsem1;
sem_t binsem2;
int *brklijenta;
void gotovo(int signal) {
	radnoV= 1;

}

void *frizerka() {
	printf("Frizerka: Otvaram salon\n");
	radnoV= 0;
	zauzeto_mjesto=0;
	while(1) {
		if(radnoV == 1) {
			ZATVORENO =1;
		}
		if(zauzeto_mjesto != 0) {
			printf("Frizerka :Idem raditi\n");
			sem_post(&cekaonica);
			sem_post(&poceo);
			sleep(3);
			sem_post(&gotov);



		} else if(radnoV != 1) {
			printf("Frizerka : Spavam dok klijenti ne dodu\n");
			sleep(1);
			sem_wait(&spavaj);
		} else {
			printf("Frizerka: zatvaram salon\n");
			pthread_exit(NULL);
		}

	}
	
}
void *klijent(void *broj) {
	int brojk = *((int *) broj);
	int zauz;
	if(brojk >= prviK) {
		sleep(rand()%(14-10+1)+10);
	}
	if(broj_mjesta != 0 && ZATVORENO != 1) {
		sem_wait(&binsem1);
		zauzeto_mjesto++;
		zauz = zauzeto_mjesto;
		broj_mjesta--;
		sem_post(&binsem1);
		sem_wait(&binsem2);
		printf("Klijent(%d) : Zelim na frizuru\n",brojk);
		printf("Klijent(%d) : Ulazim u cekaonu (%d)\n",brojk,zauz);
		sem_post(&spavaj);
		sem_post(&binsem2);
		sem_wait(&cekaonica);
		sem_wait(&poceo);
		broj_mjesta++;
		zauzeto_mjesto--;
		printf("Klijent(%d) : Frizerka mi radi frizuru\n",brojk);
		sem_wait(&gotov);
		printf("Klijent (%d) : Dobra mi je frizura :)\n",brojk);
		pthread_exit(NULL);
	} else {
		printf("Klijent (%d) :Danas nista od frizure :(\n",brojk);
			pthread_exit(NULL);
	}
	

}
void brisi() {
	sem_destroy(&poceo);
	sem_destroy(&gotov);
	sem_destroy(&cekaonica);
	sem_destroy(&binsem2);
	sem_destroy(&binsem1);
	sem_destroy(&spavaj);
	free(brklijenta);
}

void init() {

	if(sem_init(&cekaonica,1,0) != 0) {
		printf("Inicijaliziranje semfaora 1 nije uspjelo\n");
		exit(1);
	}if(sem_init(&gotov,1,0) != 0) {
		printf("Inicijaliziranje semfaora 3 nije uspjelo\n");
		exit(1);
	}if(sem_init(&poceo,1,0) != 0) {
		printf("Inicijaliziranje semfaora 4 nije uspjelo\n");
		exit(1);
	}
	if(sem_init(&binsem1,1,1) != 0) {
		printf("Inicijalizaija semafora 5 nije uspjela\n");
		exit(1);
	}
	if(sem_init(&binsem2,1,1) != 0) {
		printf("Inicijalizaija semafora 5 nije uspjela\n");
		exit(1);
	}
	if(sem_init(&spavaj,1,0) != 0) {
		printf("Inicijaliziranje semfaora 1 nije uspjelo\n");
		exit(1);
	}
}
int main(void) {
	srand((unsigned) time(NULL));
	int brojklijenata;
	int brojCekaonice;
	int prvi;
	sigset(SIGSTOP,brisi);
	sigset(SIGALRM,gotovo);
	alarm(20);
	do {
		printf("Upisite broj klijenata(po mogucnosti ne manji od 1)(klijenti + 1 frizerka)\n");
		scanf("%d",&brojklijenata);
		printf("Upisite broj mjesta u cekaonice(po mogucnosti ne manji od 1)\n");
		scanf("%d",&brojCekaonice);
		printf("Upisite broj klijenata koji ce u pocteku doci(po mogucnosti ne manji od 1)\n");
		scanf("%d",&prvi);
	}while(brojklijenata < 1 || brojCekaonice < 1 || prvi < 1  || prvi > brojklijenata);
	pthread_t th_id[brojklijenata];
	klijenti = brojklijenata;
	broj_mjesta=brojCekaonice;
	prviK = prvi;
	brklijenta=malloc(sizeof(int)*klijenti);
	init();
	for(int i = 0; i < klijenti ; i++) {
		brklijenta[i] = i;
	}
	for(int i = 0 ; i < klijenti ; i ++) {
		if(i== 0) {
			if(pthread_create(&th_id[i],NULL,(void *) frizerka ,NULL) != 0) {
				printf("Dretva frizerka se nije stvorila\n");
				exit(1);
			}
		} else {
			if(pthread_create(&th_id[i],NULL,(void *)klijent ,&brklijenta[i-1]) != 0) {
				printf("Stvaranje %d klijenta nije uspjelo\n",i);
				exit(1);
			}
		}
	}	
	for(int i = 0 ; i < klijenti ; i++) {
		pthread_join(th_id[i],NULL);
	}
	brisi();
	printf("Gotovo\n");


	return 0;
}