#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <math.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <time.h>
#include <sched.h>

#define MAX_DRETVI 5
#define DRETVI 6
int t = 0;
static int zaglavlje = 1;
int brojDretvi=0;

struct dretva
{
	int id;
	int p;
	int prio;
	int rasp;
};

struct dretva *P[MAX_DRETVI];

int nove[DRETVI][5] = {
	{ 1,  3, 4, 3, 1 },
	{ 3,  5, 6, 5, 1 },
	{ 7,  2, 3, 5, 0 },
	{ 12, 1, 5, 3, 0 },
	{ 20, 6, 3, 7, 1 },
	{ 20, 7, 4, 6, 1 },
};

void ispis_stanja(int zaglavlje) {
	int i;

	if(zaglavlje == 1) {
		printf ( "  t    AKT" );
		for ( i = 1; i < MAX_DRETVI; i++ )
			printf ( "     PR%d", i );
		printf ( "\n" );
		zaglavlje=0;
	}
	printf ( "%3d ", t );
	for ( i = 0; i < MAX_DRETVI; i++ )
		if ( P[i]->id != 0 )
			printf ( "  %d/%d/%d ",
				 P[i]->id, P[i]->prio, P[i]->p );
		else
			printf ( "  -/-/- " );
	printf ( "\n");
}

int main(void) {
	int kvant = 1;
	t = 0;
	struct dretva *temp;
	int tempprio;
	zaglavlje =1;
	for(int i = 0; i < MAX_DRETVI; i++) {
		P[i]= malloc(sizeof(struct dretva));
		if(P[i] == NULL ) {
			printf("Allocating through malloc failed!\n");

			exit(1);
		}
	}
	temp = malloc(sizeof(struct dretva));
	while(t<30) {
		if(t == 0) {
			ispis_stanja(zaglavlje);
			zaglavlje=0;
		}
		for(int i = 0; i< DRETVI; i++) {
			if(nove[i][0] == t) {
				P[brojDretvi]->id= nove[i][1];
				P[brojDretvi]->p=nove[i][2];
				P[brojDretvi]->prio=nove[i][3];
				P[brojDretvi]->rasp=nove[i][4];
				printf("Nova dretva id= %d, p= %d, prio = %d\n",P[brojDretvi]->id,P[brojDretvi]->p,P[brojDretvi]->prio);
				brojDretvi++;
			} 
			

		}
		if(brojDretvi!=0) {
			if(brojDretvi > 1) {
				
				for(int i = 0; i < brojDretvi-1; i++) {
					
					if(P[i]->id != 0) {
						if(P[i]->prio > P[i+1]->prio) {
							continue;
						} else { 
							temp = P[i];
							P[i]=P[i+1];
							P[i+1] =temp;
						}
					} else {
						break;
					}
				}
			}
			P[0]->p--;
			for(int i = 0; i< brojDretvi-1; i++) {
				if(P[i]->p == 0) {
					temp = P[i];
					P[i]=P[i+1];
					P[i+1] =temp;
				}
			}
			if(P[brojDretvi-1]->p == 0) {
				printf("Dretva %d je zavrisila\n",P[brojDretvi-1]->id);
				P[brojDretvi-1]->id= 0;
				P[brojDretvi-1]->p=0;
				P[brojDretvi-1]->prio=0;
				brojDretvi--;
			}

		}
		sleep(2);
		ispis_stanja(zaglavlje);
		t++;
	}


	return 0;
	
}
