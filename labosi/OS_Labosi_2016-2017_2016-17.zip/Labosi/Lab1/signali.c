#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <math.h>

int paus = 0;
long number=1000000001;
long last = 1000000001;
int change_pause(int sig) {
   paus = paus -1;
   return paus;
}
void periodical_print(int sig) {
   printf("Zadnji prosti broj: %ld\n",last);
}
void over(int sig) {
   printf("Zadnji prosti broj: %ld\n",last);
   printf("Terminated");
   exit(0);  
}
int primeNumber( unsigned long n ) {
   unsigned long i, max;

   if ( ( n & 1 ) == 0 ) /* je li paran? */
      return 0;

   max = sqrt(i);
   for ( i = 3; i <= max; i += 2 )
      if ( ( n % i ) == 0 )
         return 0;

   return 1; /* broj je prost! */
}


int main(void) {
      int l=0;
      sigset(SIGINT,change_pause);
      sigset(SIGTERM,over);   
      sigset(SIGALRM,periodical_print);
      struct itimerval t;
      t.it_value.tv_sec = 5;
      t.it_value.tv_usec = 500000;
   
      t.it_interval.tv_sec = 5;
      t.it_interval.tv_usec = 500000;
      setitimer ( ITIMER_REAL, &t, NULL );
      printf("I am starting to count prime numbers PID: %d\n", getpid());
      while(1) {
         l=primeNumber(number);
         if(l) {
            last = number;
         }
         ++number;
         while(paus){
            pause();
         }  
      }

      return 0;

} 




