#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/shm.h> 
#include <sys/sem.h>
#include <sys/msg.h>
#include <values.h>
#define N 50

int Id;
int *TRAZIM;
int  *BROJ ;
int *Stolovi;
static int brojs;
static int brojprocesa;
static int rezervirani = 0;
static int *brojp;
void udi_u_kriticni_odsjecak(int i) {
		TRAZIM[i] = 1;
		int max1 = BROJ[0];
		for(int j = 0;j < brojprocesa ;j++) {
			if(BROJ[i] > max1) {
			max1 = BROJ[i];
			}
		}
		BROJ[i]=max1+1;
		TRAZIM[i] = 0;
		for(int j = 0; j < brojprocesa ; j++) {
			while(TRAZIM[j]!=0) {

			}

			while(BROJ[j] != 0 && (BROJ[j] < BROJ[i] || (BROJ[j] == BROJ[i] && j < i))) {
				
			}
		}
}
void izadi_iz_kriticnog_odsjecka(int i) {
	BROJ[i] = 0;
}

void rezervacija(int i, int bs){
   
   int biram = 0; 
   int zauzeti = 0;
   int bss = 0;
   int Idstola[bs];
   int t = getpid();
      
   while(zauzeti < bs){
      bss=0;
         for(int k=0; k<bs; k++){
            if(Stolovi[k] == 0){
                  Idstola[bss] = k;
                  bss++;
               }
         }
   
      
      srand(t);
      sleep(1);
      biram = rand() % bss;
      printf("Proces %d: odabirem stol %d\n", i, Idstola[biram]+1);
      
      if(Stolovi[Idstola[biram]] == 0){
         udi_u_kriticni_odsjecak(i);    
         Stolovi[Idstola[biram]] = i;
         printf("Proces %d: rezerviram stol %d\n", i, Idstola[biram]+1);
         zauzeti++;      
      }
      else
         printf("Proces %d: neuspjela rezervacija stola %d\n", i, Idstola[biram]+1);
      printf("stanje: \n");
      for(int k=0; k<bs; k++){
         if(Stolovi[k] == 0)
            printf("-");
         else
            printf("%d", Stolovi[k]);
      }
      printf("\n");
      izadi_iz_kriticnog_odsjecka(i);
      bss--;
   }
}
void brisi(int signal) {
	(void) shmdt((int *) TRAZIM);
	(void) shmdt((int *) BROJ);
	(void) shmctl(Id, IPC_RMID, NULL);
	exit(0);

}

/*int max(int x) {
	int max1 = 0;
	for(int i = 0;i < x ;i++) {
		if(BROJ[i] > max) {
			max1 = BROJ[i];
		}
	}

	return max1;
}*/



int main(char argc, char *argv[]) {
	int procesi = atoi(argv[1]);
	int stolovi = atoi(argv[2]);
   	sigset(SIGINT, brisi);
   	brojprocesa=procesi;
   	brojs=stolovi;

   Id = shmget(IPC_PRIVATE, sizeof(int)*1024, 0600);
   
   if(Id == -1){
      printf("\n Nema zajednicke memorije");
      exit(1);
   }
   brojp = malloc(sizeof(int) * procesi);

   TRAZIM = (int *)shmat(Id, NULL, 0);
   BROJ = (int *)shmat(Id, NULL, 0) + (N+1)*sizeof(int); 
   Stolovi = (int *)shmat(Id, NULL, 0) + 2*(N+1)*sizeof(int);
   printf("broj procesa %d\n",procesi);
   printf("broj stolova %d\n",stolovi);
   
   for(int i=0; i<stolovi; i++){
      TRAZIM[i] = 0;
      BROJ[i] = 0;
      Stolovi[i] = 0;
      brojp[i] = i;
   }
   for(int i = 0; i < brojprocesa; i++){
      switch(fork()) {
         case -1 :
            fprintf(stderr,"nije uspjelo stvaranje procesa!n\n");
            exit(1);
         case 0 :
            rezervacija(brojp[i]+1,stolovi);
            exit(0);
      }
   }

   for(int i=0; i<procesi; i++){
      wait(NULL);
   }
   brisi(0);

	return 0;
}