#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

int A;

void *povecaj(void *y) {
	int i;
	int n = *((int *) y);
	for(i = 0; i < n ; i++) {
		A+=1;
	}
	pthread_exit(y);
}
int main(int argc,char *argv[]) {
	int N = atoi(argv[1]);
	int M = atoi(argv[2]);
	pthread_t thr_id[N];
	int t;
	A = 0;
	int *arg = malloc(sizeof(*arg));
        if ( arg == NULL ) {
            fprintf(stderr,"Alociranje mmorije za dretvu nije uspjelo.\n");
            exit(EXIT_FAILURE);
        }

        *arg = M;

	for(int i = 0;i < N; i++) {
		t=pthread_create(&thr_id[i],NULL,povecaj,arg);
		if(t!=0) {
			printf("Greska pri stvaranju %d.dretve!\n",i);
			exit(1);
		}	
	}
	for(int i = 0 ; i < N ; i++) {
		pthread_join(thr_id[i], NULL);	
	}
	printf("A = %d",A);
}