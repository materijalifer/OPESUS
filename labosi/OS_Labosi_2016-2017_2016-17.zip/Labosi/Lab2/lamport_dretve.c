#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <math.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/syscall.h>

int *BROJ;
int *TRAZIM;
int *Stolovi;
static int *brd;
static int brojs;
static int brojdretvi;
static int rezervirani = 0;
void udi_u_kriticni_odsjecak(int i) {
		TRAZIM[i] = 1;
			int max1 = BROJ[0];
			for(int i = 0;i < brojdretvi ;i++) {
				if(BROJ[i] > max1) {
				max1 = BROJ[i];
				}
			}
			BROJ[i]=max1+1;
			TRAZIM[i] = 0;
			for(int j = 0; j < brojdretvi ; j++) {
				while(TRAZIM[j]!=0) {

				}

				while(BROJ[j] != 0 && (BROJ[j] < BROJ[i] || (BROJ[j] == BROJ[i] && j < i))) {

				}
			}
}

void izadi_iz_kriticnog_odsjecka(int i) {
	BROJ[i] = 0;
}

void *rezervacija(void *x) {
	int brojd = *((int *) x);
	int biram;
	srand((unsigned) time(NULL));
	while (rezervirani <= brojs) {
		sleep(1);
		biram = rand()%(brojs-0+1);
		printf("Dretva %d: odabirem stol %d\n",brojd+1,biram);
		if(Stolovi[biram] == 0) {
			udi_u_kriticni_odsjecak(brojd);
			Stolovi[biram] =brojd+1;
				printf("Dretva %d: rezerviram stol %d stanje:\n",brojd+1,biram);
				rezervirani++;
				for(int i = 0; i < brojs ; i++) {
					if(Stolovi[i] == 0) {
						printf("-");
					} else {
						printf("%d",Stolovi[i]);
					}
				}
				
		} else {
			printf("Dretva %d: neuspjela rezervacija stola %d stanje :\n",brojd+1,biram);
			for(int i = 0; i < brojs ; i++) {
					if(Stolovi[i] == 0) {
						printf("-");
					} else {
						printf("%d",Stolovi[i]);
					}

			}
		}
			printf("\n");
			izadi_iz_kriticnog_odsjecka(brojd);
			

 	}
}	

/*int max(int x) {
	int max1 = 0;
	for(int i = 0;i < x ;i++) {
		if(BROJ[i] > max) {
			max1 = BROJ[i];
		}
	}

	return max1;
}*/



int main(char argc, char *argv[]) {
	int dretve = atoi(argv[1]);
	int stolovi = atoi(argv[2]);
	int t;
	brojs=stolovi;
	brojdretvi=dretve;
	pthread_t thr_id[dretve];
	brd=malloc(sizeof(int)*dretve);
	TRAZIM = malloc(sizeof(int) *dretve);
	BROJ = malloc(sizeof(int) * dretve);
	Stolovi = malloc(sizeof(int) * stolovi);

	for(int i=0; i<stolovi; i++){
		TRAZIM[i] = 0;
        BROJ[i] = 0;
		Stolovi[i] = 0;
		brd[i]=i;
	}
	if( TRAZIM == NULL || BROJ == NULL || Stolovi == NULL,brd == NULL) {
		fprintf(stderr,"Alociranje mmorije za dretvu nije uspjelo.\n");
		exit(0);
	}
	
	for(int i = 0; i < dretve ; i++) {
		
		if(pthread_create(&thr_id[i],NULL,(void*)rezervacija,&brd[i]) != 0) {
			printf("Stvaranje dretve %d. nije uspjelo!\n",i+1);
			exit(0);
		}else {
			printf("%d. dretva je stvorena\n",i+1);
			TRAZIM[i]=thr_id[i];
		}
		
	}

	for(int i = 0; i < dretve ;i++) {
		pthread_join(thr_id[i], NULL);
	}

	free(TRAZIM);
	free(BROJ);
	free(Stolovi);
	

	return 0;
}
